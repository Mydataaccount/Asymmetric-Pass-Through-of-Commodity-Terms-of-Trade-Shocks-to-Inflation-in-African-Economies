"""
00_dataprep.py
Prepare the analysis panel for:
"Asymmetric Pass-Through of Commodity Terms-of-Trade Shocks to Inflation in
 African Economies: The Role of the CFA Franc Peg"
Journal of African Economies submission.

Input : lp_panel.csv (global commodity-exporter panel, monthly 1990-2026)
Output: africa_panel.parquet (cleaned 15-country African sub-panel)
"""
import pandas as pd, numpy as np

SRC = "/root/.claude/uploads/f938f7e0-43c9-5a51-8936-2022d3f5d8a7/7095d97c-lp_panel.csv"
OUT = "/root/jae_paper/output/africa_panel.csv"

# --- 15 African commodity exporters in the panel -----------------------------
AFRICA = ['AGO','BEN','CAF','CMR','COD','COG','DZA','GAB','LBR','LBY',
          'MOZ','MRT','NER','NGA','ZMB']
# CFA franc zone (hard institutional peg to FRF/EUR): WAEMU + CEMAC members here
CFA    = ['BEN','CAF','CMR','COG','GAB','NER']

COUNTRY_NAMES = {
 'AGO':'Angola','BEN':'Benin','CAF':'Central African Rep.','CMR':'Cameroon',
 'COD':'DR Congo','COG':'Congo, Rep.','DZA':'Algeria','GAB':'Gabon',
 'LBR':'Liberia','LBY':'Libya','MOZ':'Mozambique','MRT':'Mauritania',
 'NER':'Niger','NGA':'Nigeria','ZMB':'Zambia'}

def winsorize(s, lo=0.01, hi=0.99):
    ql, qh = s.quantile(lo), s.quantile(hi)
    return s.clip(ql, qh)

def main():
    df = pd.read_csv(SRC, parse_dates=['date'])
    d = df[df.country_code.isin(AFRICA)].copy()
    d = d.sort_values(['country_code','date']).reset_index(drop=True)

    # --- regime variables ----------------------------------------------------
    d['cfa']      = d.country_code.isin(CFA).astype(int)          # primary regime
    d['nonpeg']   = 1 - d['cfa']                                  # flexible/managed
    # de facto peg dummy from source (USD-volatility based) kept for robustness
    d['defacto_peg'] = d['state_peg']

    # --- clean the dependent variables --------------------------------------
    # inflation has implausible extremes (CPI rebasing / redenomination breaks)
    for v in ['infl_yoy','infl_mom']:
        d[v+'_raw'] = d[v]
        d[v] = winsorize(d[v], 0.01, 0.99)

    # --- shock variables (already sign-decomposed 12m log changes) ----------
    # shock_pos = max(d_shock_12m,0), shock_neg = min(d_shock_12m,0)
    # rest-of-world (exogenous) counterparts: shock_rw_pos / shock_rw_neg
    # scale to percentage points for readable coefficients (x100)
    for v in ['shock_pos','shock_neg','shock_rw_pos','shock_rw_neg',
              'd_shock_12m','d_shock_rw_12m']:
        d[v+'_pp'] = d[v]*100.0

    # --- controls ------------------------------------------------------------
    d['dlfx_1m']   = d['d_log_fx_1m']*100.0        # monthly FX depreciation, pp
    d['fxvol']     = d['fx_vol_12m']*100.0
    d['resmonths'] = d['reserves_months']
    d['polrate']   = d['rate_level']               # best-available policy/mm rate
    d['country']   = d.country_code
    d['name']      = d.country_code.map(COUNTRY_NAMES)

    # --- effective-sample flag ----------------------------------------------
    core = ['infl_yoy','shock_pos','shock_neg']
    d['insample'] = d[core].notna().all(axis=1).astype(int)

    d.to_csv(OUT, index=False)
    print("Saved", OUT, d.shape)
    print("\nEffective (infl+shocks) obs by country / regime:")
    eff = d[d.insample==1]
    tab = eff.groupby(['cfa','country']).size()
    print(tab)
    print("\nCFA effective obs:", eff[eff.cfa==1].shape[0],
          "| non-CFA:", eff[eff.cfa==0].shape[0])
    print("Date range (effective):", eff.date.min().date(), "->", eff.date.max().date())

if __name__ == "__main__":
    main()
