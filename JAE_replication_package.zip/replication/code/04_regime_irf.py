"""
04_regime_irf.py -- regime-SPECIFIC IRFs with correct SEs.
Re-parameterize: interact each shock with regime indicators directly
(shock x flex, shock x cfa) with NO common base term, so each coefficient is
the regime-specific pass-through with its own Driscoll-Kraay SE.
"""
import pandas as pd, numpy as np
from lp_engine import run_lp

PANEL="/root/jae_paper/output/africa_panel.csv"; OUT="/root/jae_paper/output"
H=list(range(0,25))
d=pd.read_csv(PANEL,parse_dates=['date']).sort_values(['country','date'])
d['flex']=1-d['cfa']
for L in [1,2,12]: d[f'l{L}_infl']=d.groupby('country')['infl_yoy'].shift(L)
d['l1_shkpos']=d.groupby('country')['shock_pos_pp'].shift(1)
d['l1_shkneg']=d.groupby('country')['shock_neg_pp'].shift(1)
# regime-specific shock regressors
d['pos_flex']=d.shock_pos_pp*d.flex; d['pos_cfa']=d.shock_pos_pp*d.cfa
d['neg_flex']=d.shock_neg_pp*d.flex; d['neg_cfa']=d.shock_neg_pp*d.cfa
CTRL=['l1_infl','l2_infl','l12_infl','l1_shkpos','l1_shkneg']

reg=run_lp(d,'infl_yoy',['pos_flex','pos_cfa','neg_flex','neg_cfa'],CTRL,H,cfa_interact=False)
reg.to_csv(f"{OUT}/lp_regime_specific.csv",index=False)
print("Regime-specific IRFs saved. Key horizons:")
for term in ['pos_flex','pos_cfa','neg_flex','neg_cfa']:
    s=reg[reg.term==term].set_index('horizon')
    print(f"{term:9s}: "+" ".join([f"h{h}:{s.loc[h,'coef']:+.3f}" for h in [0,6,12,18,24]]))
