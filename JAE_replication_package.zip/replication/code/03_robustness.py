"""
03_robustness.py -- robustness of the key result (negative-shock x CFA interaction
and positive-shock pass-through) across specifications. Reports coefficients at
h=12 for a compact robustness table, plus full paths saved for appendix.
"""
import pandas as pd, numpy as np, json
from lp_engine import run_lp

PANEL="/root/jae_paper/output/africa_panel.csv"; OUT="/root/jae_paper/output"
H=list(range(0,25)); HKEY=12

d0=pd.read_csv(PANEL,parse_dates=['date']).sort_values(['country','date'])
def add_ctrl(d):
    d=d.copy()
    for L in [1,2,12]: d[f'l{L}_infl']=d.groupby('country')['infl_yoy'].shift(L)
    d['l1_shkpos']=d.groupby('country')['shock_pos_pp'].shift(1)
    d['l1_shkneg']=d.groupby('country')['shock_neg_pp'].shift(1)
    return d
CTRL=['l1_infl','l2_infl','l12_infl','l1_shkpos','l1_shkneg']
d=add_ctrl(d0)

def keyrow(name, tab):
    """extract h12 coefs for pos, neg (flexible base) and neg x cfa."""
    t=tab.set_index(['term','horizon'])
    def g(term):
        try:
            row=t.loc[(term,HKEY)]; return row['coef'],row['p']
        except: return np.nan,np.nan
    pos=g('shock_pos_pp'); posx=g('shock_pos_pp_x_cfa')
    neg=g('shock_neg_pp'); negx=g('shock_neg_pp_x_cfa')
    return {'spec':name,'pos_flex':round(pos[0],3),'pos_p':round(pos[1],3),
            'posXcfa':round(posx[0],3),'posXcfa_p':round(posx[1],3),
            'neg_flex':round(neg[0],3),'neg_p':round(neg[1],3),
            'negXcfa':round(negx[0],3),'negXcfa_p':round(negx[1],3)}

rows=[]; paths={}

# R0: baseline (own shock) for reference
t=run_lp(d,'infl_yoy',['shock_pos_pp','shock_neg_pp'],CTRL,H,cfa_interact=True)
rows.append(keyrow('Baseline (own ToT shock)',t)); paths['baseline']=t.to_dict('records')

# R1: rest-of-world EXOGENOUS commodity shock
d['l1_shkpos_rw']=d.groupby('country')['shock_rw_pos_pp'].shift(1)
d['l1_shkneg_rw']=d.groupby('country')['shock_rw_neg_pp'].shift(1)
CTRLrw=['l1_infl','l2_infl','l12_infl','l1_shkpos_rw','l1_shkneg_rw']
trw=run_lp(d,'infl_yoy',['shock_rw_pos_pp','shock_rw_neg_pp'],CTRLrw,H,cfa_interact=True)
# rename terms so keyrow works
trw2=trw.copy(); trw2['term']=trw2['term'].str.replace('shock_rw','shock',regex=False)
rows.append(keyrow('RoW exogenous shock',trw2)); paths['row']=trw.to_dict('records')

# R2: monthly inflation (annualized) as dependent
d['infl_mom_ann']=d['infl_mom']*12
t=run_lp(d,'infl_mom_ann',['shock_pos_pp','shock_neg_pp'],CTRL,H,cfa_interact=True)
rows.append(keyrow('MoM inflation (annualized)',t))

# R3: exclude crisis (bust) months
dnb=d[d.bust!=1].copy()
t=run_lp(dnb,'infl_yoy',['shock_pos_pp','shock_neg_pp'],CTRL,H,cfa_interact=True)
rows.append(keyrow('Exclude bust months',t))

# R4: two-way FE (country + time) -> differential-exposure identification
t=run_lp(d,'infl_yoy',['shock_pos_pp','shock_neg_pp'],CTRL,H,cfa_interact=True,time_effects=True)
rows.append(keyrow('Add time fixed effects',t))

# R5: drop thin panels (MRT, COD)
ddrop=d[~d.country.isin(['MRT','COD'])].copy()
t=run_lp(ddrop,'infl_yoy',['shock_pos_pp','shock_neg_pp'],CTRL,H,cfa_interact=True)
rows.append(keyrow('Drop MRT & COD (thin)',t))

# R6: de-facto peg dummy instead of CFA (as regime moderator)
d2=d.copy(); d2['cfa']=d2['defacto_peg']  # engine interacts on 'cfa' column
d2=d2.dropna(subset=['cfa'])
t=run_lp(d2,'infl_yoy',['shock_pos_pp','shock_neg_pp'],CTRL,H,cfa_interact=True)
r=keyrow('De-facto peg (state_peg)',t); rows.append(r)

rob=pd.DataFrame(rows)
rob.to_csv(f"{OUT}/robustness.csv",index=False)
json.dump(paths,open(f"{OUT}/robustness_paths.json","w"),indent=2)
pd.set_option('display.width',200)
print(rob.to_string(index=False))
