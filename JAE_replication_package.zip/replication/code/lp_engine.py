"""
lp_engine.py -- reusable panel local-projection estimator (Jorda 2005).

Model at horizon h:
    y_{i,t+h} = a_i + sum_k b_k^h X_{k,i,t} + controls + e_{i,t+h}
Country (entity) fixed effects; Driscoll-Kraay SEs (Bartlett kernel) to correct
for cross-sectional dependence and the serial correlation induced by
overlapping 12-month inflation windows.
"""
import numpy as np, pandas as pd
from linearmodels.panel import PanelOLS

def _prep(df):
    d=df.copy().sort_values(['country','date'])
    d['t']=d.groupby('country').cumcount()
    return d

def build_lead(d, y, h):
    d=d.copy()
    d['ylead']=d.groupby('country')[y].shift(-h)
    return d

def run_lp(df, y, shock_vars, controls, horizons, cfa_interact=False,
           time_effects=False, dk_lags=None):
    """
    Returns tidy DataFrame: horizon, term, coef, se, t, p, ci_lo, ci_hi, nobs.
    shock_vars: list of base regressors (e.g., ['shock_pos_pp','shock_neg_pp'])
    If cfa_interact: adds shock*cfa terms (cfa absorbed by entity FE).
    """
    d=_prep(df)
    terms=list(shock_vars)
    if cfa_interact:
        for s in shock_vars:
            d[s+'_x_cfa']=d[s]*d['cfa']
            terms.append(s+'_x_cfa')
    rhs=terms+controls
    rows=[]
    for h in horizons:
        dh=build_lead(d,y,h)
        cols=['ylead']+rhs+['country','date']
        dh=dh.dropna(subset=['ylead']+rhs)
        if dh.empty: continue
        dh=dh.set_index(['country','date'])
        exog=dh[rhs]
        L=dk_lags if dk_lags is not None else int(np.ceil(1.5*(h+12)))
        mod=PanelOLS(dh['ylead'],exog,entity_effects=True,
                     time_effects=time_effects,drop_absorbed=True,check_rank=False)
        res=mod.fit(cov_type='kernel',kernel='bartlett',bandwidth=L)
        for term in terms:
            if term in res.params.index:
                b=res.params[term]; se=res.std_errors[term]
                rows.append(dict(horizon=h,term=term,coef=b,se=se,
                                 t=b/se,p=res.pvalues[term],
                                 ci_lo=b-1.96*se,ci_hi=b+1.96*se,
                                 nobs=int(res.nobs)))
    return pd.DataFrame(rows)

def wald_symmetry(df, y, controls, horizons, cfa_interact=False, dk_lags=None):
    """
    Test H0: coef(shock_pos)=coef(shock_neg) at each horizon (symmetry).
    If cfa_interact, also test H0: interaction terms jointly zero (regime neutral).
    Returns DataFrame: horizon, chi2_sym, p_sym, [chi2_regime, p_regime].
    """
    d=_prep(df)
    base=['shock_pos_pp','shock_neg_pp']
    terms=list(base)
    if cfa_interact:
        for s in base:
            d[s+'_x_cfa']=d[s]*d['cfa']; terms.append(s+'_x_cfa')
    rhs=terms+controls
    out=[]
    for h in horizons:
        dh=build_lead(d,y,h).dropna(subset=['ylead']+rhs).set_index(['country','date'])
        L=dk_lags if dk_lags is not None else int(np.ceil(1.5*(h+12)))
        res=PanelOLS(dh['ylead'],dh[rhs],entity_effects=True,drop_absorbed=True,
                     check_rank=False).fit(cov_type='kernel',kernel='bartlett',bandwidth=L)
        # symmetry: shock_pos - shock_neg = 0
        r={'horizon':h}
        try:
            w=res.wald_test(formula='shock_pos_pp = shock_neg_pp')
            r['chi2_sym']=float(w.stat); r['p_sym']=float(w.pval)
        except Exception as e:
            r['chi2_sym']=np.nan; r['p_sym']=np.nan
        if cfa_interact:
            try:
                w2=res.wald_test(formula='shock_pos_pp_x_cfa = 0, shock_neg_pp_x_cfa = 0')
                r['chi2_regime']=float(w2.stat); r['p_regime']=float(w2.pval)
            except Exception:
                r['chi2_regime']=np.nan; r['p_regime']=np.nan
        out.append(r)
    return pd.DataFrame(out)
