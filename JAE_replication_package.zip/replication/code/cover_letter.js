const fs=require('fs');
const {Document,Packer,Paragraph,TextRun,AlignmentType}=require('docx');
const FONT='Times New Roman';const OUT='/root/jae_paper/output/JAE_cover_letter.docx';
const today=new Date().toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric'});
function P(text,o={}){o=Object.assign({size:22,after:200,align:AlignmentType.JUSTIFIED,bold:false,italics:false},o);
  return new Paragraph({alignment:o.align,spacing:{after:o.after,line:276},
    children:[new TextRun({text,font:FONT,size:o.size,bold:o.bold,italics:o.italics})]});}
function BR(n=1){const a=[];for(let i=0;i<n;i++)a.push(new Paragraph({children:[new TextRun({text:'',font:FONT})]}));return a;}

const body=[
 P('Mohamed Benbouziane',{after:0,bold:true}),
 P('Professor of Economics, Faculty of Economics and Management',{after:0}),
 P('University of Tlemcen, B.P. 226, Tlemcen, Algeria',{after:0}),
 P('mohamed.benbouziane@univ-tlemcen.dz',{after:200}),
 P(today,{after:300}),
 P('The Editors',{after:0,bold:true}),
 P('Journal of African Economies',{after:0}),
 P('Centre for the Study of African Economies, University of Oxford',{after:300}),
 P('Dear Editors,',{after:200}),
 P('Re: Submission of “Asymmetric Pass-Through of Commodity Terms-of-Trade Shocks to Inflation in African Economies: The Role of the CFA Franc Peg”.',{bold:true}),
 P('On behalf of my co-authors, Dr Abdelhadi Benghalem (Oran Graduate School of Economics, and Economic Research Forum) and Ms Rabia Meriem Benbouziane (Istanbul Technical University), I am pleased to submit the above manuscript for consideration as an original research article in the Journal of African Economies. The paper studies a question of first-order importance for African macroeconomic management: when a commodity terms-of-trade shock hits an African economy, how much of it reaches consumer-price inflation, does the answer depend on the sign of the shock, and how is it shaped by the exchange-rate regime?'),
 P('Using a monthly panel of fifteen African commodity exporters over 2003-2026 and country-specific commodity terms-of-trade shocks, we estimate the dynamic pass-through to inflation with panel local projections and dependence-robust inference. Two findings stand out. First, pass-through is asymmetric: favourable shocks raise inflation along a hump-shaped path peaking near 0.10 percentage points at about ten months, while adverse shocks act more slowly, and the null of symmetric transmission is rejected at business-cycle horizons. Second, and central to the paper, the asymmetry is governed by the exchange-rate regime. Under flexible and managed regimes an adverse shock is strongly inflationary, as the currency depreciates and imported inflation dominates, whereas under the CFA franc peg the same shock is mildly disinflationary, because the anchor closes the depreciation channel. Regime neutrality is rejected at better than the one-percent level, and the result survives an exogenous rest-of-world commodity shock that guards against reverse causality, alternative inflation measures, the exclusion of crisis episodes, two-way fixed effects, and the removal of thin country panels.'),
 P('The paper speaks directly to themes the Journal has featured prominently, including the continent’s exposure and resilience to multiple external shocks and the long-running debate over nominal anchors and the CFA franc zone. Its contribution is to join three literatures that have largely developed in parallel: commodity shocks, asymmetric price transmission, and exchange-rate regimes in Africa, within a credible identification strategy, and to organise the findings around a simple two-channel (fiscal-absorption and exchange-rate) framework with testable predictions. The results carry concrete policy implications: they argue for sign-contingent monetary reaction functions in commodity exporters and quantify a first-order inflation-stabilisation benefit of a credible peg, while showing that even a peg leaves the fiscal channel of favourable shocks to be managed.'),
 P('On behalf of all authors, I confirm that the manuscript is original, has not been published previously, and is not under consideration at any other journal. There are no conflicts of interest to declare. A complete replication package (data, code and output) is available and will be deposited in accordance with the Journal’s data-availability policy. The manuscript is approximately 9,000 words and contains four figures and seven tables.'),
 P('Thank you for considering this submission. I would be glad to suggest suitable referees or to provide any further information the editorial office may require.'),
 ...BR(1),
 P('Yours sincerely,',{after:200}),
 ...BR(2),
 P('Mohamed Benbouziane',{after:0,bold:true}),
 P('Professor of Economics, University of Tlemcen, Algeria',{after:0}),
 P('On behalf of all co-authors',{after:0,italics:true}),
];
const doc=new Document({creator:'Cover letter',sections:[{
  properties:{page:{size:{width:12240,height:15840},margin:{top:1440,bottom:1440,left:1440,right:1440}}},
  children:body}]});
Packer.toBuffer(doc).then(b=>{fs.writeFileSync(OUT,b);console.log('WROTE',OUT,b.length);});
