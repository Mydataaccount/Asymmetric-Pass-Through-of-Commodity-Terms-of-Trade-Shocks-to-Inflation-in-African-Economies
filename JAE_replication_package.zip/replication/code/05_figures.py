"""
05_figures.py -- IRF figures (Fig 4,5,6) from LP output.
"""
import pandas as pd, numpy as np
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
OUT="/root/jae_paper/output"; FIG="/root/jae_paper/figures"
plt.rcParams.update({"font.size":10,"axes.spines.top":False,"axes.spines.right":False,
                     "figure.dpi":150,"savefig.bbox":"tight"})
FLEX="#d62728"; CFA="#1f77b4"; POS="#2ca02c"; NEG="#d62728"

base=pd.read_csv(f"{OUT}/lp_baseline.csv")
rs=pd.read_csv(f"{OUT}/lp_regime_specific.csv")
wald=pd.read_csv(f"{OUT}/wald_baseline.csv")

def band(ax,s,color,label,ls='-',sign=1):
    # sign=-1 converts coef on shock_neg (a negative-valued regressor) into the
    # inflation response to a 1pp ADVERSE shock, so 'up' always = inflationary.
    c=sign*s.coef
    ax.plot(s.horizon,c,color=color,lw=2,label=label,ls=ls)
    ax.fill_between(s.horizon,c-1.645*s.se,c+1.645*s.se,color=color,alpha=.18)
    ax.axhline(0,color='k',lw=.8)

# ============ FIGURE 4: baseline asymmetric IRFs ============================
fig,ax=plt.subplots(1,2,figsize=(10,4),sharey=True)
sp=base[base.term=='shock_pos_pp'].set_index('horizon').reset_index()
sn=base[base.term=='shock_neg_pp'].set_index('horizon').reset_index()
band(ax[0],sp,POS,'Positive shock')
ax[0].set_title('A. Response to a +1pp positive commodity shock')
band(ax[1],sn,NEG,'Negative shock',sign=-1)
ax[1].set_title('B. Response to a 1pp adverse commodity shock')
for a in ax:
    a.set_xlabel('Months after shock (h)'); a.set_xlim(0,24)
ax[0].set_ylabel('Δ inflation, pp')
fig.suptitle("Figure 4. Asymmetric pass-through of commodity terms-of-trade shocks to inflation\n"
             "(panel local projections, country FE, Driscoll–Kraay 90% bands)",fontsize=11)
fig.tight_layout(); fig.savefig(f"{FIG}/fig4_baseline_irf.png"); plt.close(fig)

# ============ FIGURE 5: regime-specific IRFs (the key result) ===============
fig,ax=plt.subplots(1,2,figsize=(10,4.2),sharey=True)
band(ax[0],rs[rs.term=='pos_flex'].reset_index(),FLEX,'Flexible / managed')
band(ax[0],rs[rs.term=='pos_cfa'].reset_index(),CFA,'CFA peg',ls='--')
ax[0].set_title('A. Positive commodity shock')
band(ax[1],rs[rs.term=='neg_flex'].reset_index(),FLEX,'Flexible / managed',sign=-1)
band(ax[1],rs[rs.term=='neg_cfa'].reset_index(),CFA,'CFA peg',ls='--',sign=-1)
ax[1].set_title('B. Adverse commodity shock')
for a in ax:
    a.set_xlabel('Months after shock (h)'); a.set_xlim(0,24); a.legend(fontsize=8,loc='upper left')
ax[0].set_ylabel('Δ inflation, pp')
fig.suptitle("Figure 5. Commodity-shock pass-through by exchange-rate regime\n"
             "(regime-specific panel local projections, 90% Driscoll–Kraay bands)",fontsize=11)
fig.tight_layout(); fig.savefig(f"{FIG}/fig5_regime_irf.png"); plt.close(fig)

# ============ FIGURE 6: symmetry test p-value path =========================
fig,ax=plt.subplots(figsize=(6.5,3.8))
w=wald.set_index('horizon')
ax.plot(w.index,w.p_sym,color='k',lw=2,marker='o',ms=3)
ax.axhline(0.05,color=NEG,ls='--',lw=1); ax.axhline(0.10,color='gray',ls=':',lw=1)
ax.text(20,0.055,'5%',color=NEG,fontsize=8); ax.text(20,0.105,'10%',color='gray',fontsize=8)
ax.set_xlabel('Months after shock (h)'); ax.set_ylabel('p-value, H0: symmetry')
ax.set_xlim(0,24); ax.set_ylim(0,1)
ax.set_title("Figure 6. Test of symmetric pass-through by horizon\n(Wald test: β+ = β−)",fontsize=10)
fig.tight_layout(); fig.savefig(f"{FIG}/fig6_symmetry.png"); plt.close(fig)
print("Saved fig4, fig5, fig6.")
