"""
02_estimate.py -- main LP estimation + tests. Saves tidy CSVs + JSON summary.
"""
import pandas as pd, numpy as np, json
from lp_engine import run_lp, wald_symmetry

PANEL="/root/jae_paper/output/africa_panel.csv"; OUT="/root/jae_paper/output"
H=list(range(0,25))

d=pd.read_csv(PANEL,parse_dates=['date'])
d=d[d.insample==1 | d['infl_yoy'].notna()].copy() if False else d.copy()
d=d.sort_values(['country','date'])

# predetermined controls (lags only -> avoid blocking the FX channel)
for L in [1,2,12]:
    d[f'l{L}_infl']=d.groupby('country')['infl_yoy'].shift(L)
for L in [1]:
    d[f'l{L}_shkpos']=d.groupby('country')['shock_pos_pp'].shift(L)
    d[f'l{L}_shkneg']=d.groupby('country')['shock_neg_pp'].shift(L)
CTRL=['l1_infl','l2_infl','l12_infl','l1_shkpos','l1_shkneg']

SH=['shock_pos_pp','shock_neg_pp']
SHrw=['shock_rw_pos_pp','shock_rw_neg_pp']

print("Running baseline asymmetric LP (own commodity shock)...")
base=run_lp(d,'infl_yoy',SH,CTRL,H)
base.to_csv(f"{OUT}/lp_baseline.csv",index=False)

print("Running regime-interacted LP (shock x CFA)...")
regime=run_lp(d,'infl_yoy',SH,CTRL,H,cfa_interact=True)
regime.to_csv(f"{OUT}/lp_regime.csv",index=False)

print("Running symmetry & regime Wald tests...")
w_base=wald_symmetry(d,'infl_yoy',CTRL,H,cfa_interact=False)
w_base.to_csv(f"{OUT}/wald_baseline.csv",index=False)
w_reg=wald_symmetry(d,'infl_yoy',CTRL,H,cfa_interact=True)
w_reg.to_csv(f"{OUT}/wald_regime.csv",index=False)

# cumulative multipliers (sum of coefficients up to h) -- report peak & 12m/24m
def summ(df,term):
    s=df[df.term==term].set_index('horizon')
    return s
res={}
for term in SH:
    s=summ(base,term)
    peak_h=int(s.coef.abs().idxmax())
    res[term]={'peak_h':peak_h,'peak_coef':round(s.loc[peak_h,'coef'],3),
               'peak_se':round(s.loc[peak_h,'se'],3),
               'h0':round(s.loc[0,'coef'],3),'h6':round(s.loc[6,'coef'],3),
               'h12':round(s.loc[12,'coef'],3),'h24':round(s.loc[24,'coef'],3),
               'p12':round(float(s.loc[12,'p']),4)}
# regime interaction summary
for term in ['shock_pos_pp_x_cfa','shock_neg_pp_x_cfa']:
    s=summ(regime,term)
    res[term]={'h6':round(s.loc[6,'coef'],3),'h12':round(s.loc[12,'coef'],3),
               'p6':round(float(s.loc[6,'p']),4),'p12':round(float(s.loc[12,'p']),4)}
# effective pass-through in CFA at h12 = beta + delta
r12=regime[regime.horizon==12].set_index('term')
res['cfa_effective']={
  'pos_flex':round(r12.loc['shock_pos_pp','coef'],3),
  'pos_cfa':round(r12.loc['shock_pos_pp','coef']+r12.loc['shock_pos_pp_x_cfa','coef'],3),
  'neg_flex':round(r12.loc['shock_neg_pp','coef'],3),
  'neg_cfa':round(r12.loc['shock_neg_pp','coef']+r12.loc['shock_neg_pp_x_cfa','coef'],3)}
# symmetry test summary
res['sym_test']={'p_h0':round(float(w_base.set_index('horizon').loc[0,'p_sym']),4),
                 'p_h6':round(float(w_base.set_index('horizon').loc[6,'p_sym']),4),
                 'p_h12':round(float(w_base.set_index('horizon').loc[12,'p_sym']),4)}
res['regime_test']={'p_h6':round(float(w_reg.set_index('horizon').loc[6,'p_regime']),4),
                    'p_h12':round(float(w_reg.set_index('horizon').loc[12,'p_regime']),4)}

json.dump(res,open(f"{OUT}/results_lp.json","w"),indent=2)
print(json.dumps(res,indent=2))
print("\nSaved lp_baseline, lp_regime, wald_*, results_lp.json")
