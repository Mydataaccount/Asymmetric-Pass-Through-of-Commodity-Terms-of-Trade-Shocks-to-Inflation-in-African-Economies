// make_docx.js -- assemble the JAE manuscript.
const fs = require('fs');
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, BorderStyle, ShadingType,
  ImageRun, PageBreak, Footer, PageNumber
} = require('docx');

const FIG = '/root/jae_paper/figures';
const OUT = '/root/jae_paper/output/JAE_manuscript.docx';

// ---------- helpers ----------------------------------------------------------
const FONT = 'Times New Roman';
function P(text, opts={}) {
  const o = Object.assign({size:22, spacingAfter:120, align:AlignmentType.JUSTIFIED,
                           bold:false, italics:false, firstLine:false, spacingBefore:0}, opts);
  return new Paragraph({
    alignment:o.align,
    spacing:{after:o.spacingAfter, before:o.spacingBefore, line:276},
    indent:o.firstLine?{firstLine:360}:undefined,
    children:[new TextRun({text, font:FONT, size:o.size, bold:o.bold, italics:o.italics})]
  });
}
// paragraph from runs (for mixed formatting)
function PR(runs, opts={}) {
  const o = Object.assign({spacingAfter:120, align:AlignmentType.JUSTIFIED, firstLine:false}, opts);
  return new Paragraph({
    alignment:o.align, spacing:{after:o.spacingAfter, line:276},
    indent:o.firstLine?{firstLine:360}:undefined,
    children:runs.map(r=>new TextRun({text:r.t, font:FONT, size:r.size||22,
                       bold:!!r.b, italics:!!r.i, subScript:!!r.sub, superScript:!!r.sup}))
  });
}
function H1(text){return new Paragraph({heading:HeadingLevel.HEADING_1,spacing:{before:240,after:120},
  children:[new TextRun({text,font:FONT,size:26,bold:true,color:'000000'})]});}
function H2(text){return new Paragraph({heading:HeadingLevel.HEADING_2,spacing:{before:180,after:100},
  children:[new TextRun({text,font:FONT,size:23,bold:true,italics:true,color:'000000'})]});}
function img(path, w, h){
  return new Paragraph({alignment:AlignmentType.CENTER, spacing:{before:120,after:60},
    children:[new ImageRun({type:'png', data:fs.readFileSync(path), transformation:{width:w,height:h}})]});
}
function cap(text){return new Paragraph({alignment:AlignmentType.LEFT, spacing:{after:200},
  children:[new TextRun({text, font:FONT, size:18, italics:true})]});}

// build a table from array-of-arrays; first row = header
function mkTable(rows, widths, opts={}){
  const total = widths.reduce((a,b)=>a+b,0);
  const trows = rows.map((r,ri)=>new TableRow({
    tableHeader: ri===0,
    children: r.map((c,ci)=>new TableCell({
      width:{size:widths[ci],type:WidthType.DXA},
      margins:{top:40,bottom:40,left:80,right:80},
      borders: ri===0?{bottom:{style:BorderStyle.SINGLE,size:4,color:'000000'}}:undefined,
      children:[new Paragraph({alignment: ci===0?AlignmentType.LEFT:AlignmentType.CENTER,
        spacing:{after:0,line:240},
        children:[new TextRun({text:String(c), font:FONT, size:opts.size||17, bold:ri===0})]})]
    }))
  }));
  return new Table({columnWidths:widths, width:{size:total,type:WidthType.DXA}, rows:trows,
    borders:{top:{style:BorderStyle.SINGLE,size:4,color:'000000'},
             bottom:{style:BorderStyle.SINGLE,size:4,color:'000000'},
             left:{style:BorderStyle.NONE},right:{style:BorderStyle.NONE},
             insideHorizontal:{style:BorderStyle.NONE},
             insideVertical:{style:BorderStyle.NONE}}});
}

const body = [];
const add = (...x)=>x.forEach(e=>body.push(e));

// ======================= TITLE PAGE =========================================
add(new Paragraph({alignment:AlignmentType.CENTER, spacing:{before:1200,after:200},
  children:[new TextRun({text:'Asymmetric Pass-Through of Commodity Terms-of-Trade Shocks to Inflation in African Economies: The Role of the CFA Franc Peg',
    font:FONT, size:32, bold:true})]}));
// author block
add(PR([
  {t:'Mohamed Benbouziane',size:24},{t:'a,*',sup:true,size:24},
  {t:'      Abdelhadi Benghalem',size:24},{t:'b',sup:true,size:24},
  {t:'      Rabia Meriem Benbouziane',size:24},{t:'c',sup:true,size:24}
],{align:AlignmentType.CENTER,spacingAfter:80}));
add(PR([{t:'a',sup:true,size:18},{t:' Faculty of Economics and Management, University of Tlemcen, Algeria',size:18}],{align:AlignmentType.CENTER,spacingAfter:20}));
add(PR([{t:'b',sup:true,size:18},{t:' Oran Graduate School of Economics, and Economic Research Forum (ERF), Algeria',size:18}],{align:AlignmentType.CENTER,spacingAfter:20}));
add(PR([{t:'c',sup:true,size:18},{t:' Istanbul Technical University, Türkiye',size:18}],{align:AlignmentType.CENTER,spacingAfter:20}));
add(PR([{t:'* Corresponding author: mohamed.benbouziane@univ-tlemcen.dz',size:18,i:true}],{align:AlignmentType.CENTER,spacingAfter:160}));
add(new Paragraph({alignment:AlignmentType.CENTER, spacing:{after:120},
  children:[new TextRun({text:'Prepared for submission to the Journal of African Economies', font:FONT, size:22, italics:true})]}));
add(new Paragraph({alignment:AlignmentType.CENTER, spacing:{after:600},
  children:[new TextRun({text:'This version: '+new Date().toISOString().slice(0,10), font:FONT, size:20})]}));

// Abstract
add(new Paragraph({alignment:AlignmentType.CENTER, spacing:{before:200,after:120},
  children:[new TextRun({text:'Abstract', font:FONT, size:24, bold:true})]}));
add(new Paragraph({alignment:AlignmentType.JUSTIFIED, spacing:{after:200,line:276}, indent:{left:720,right:720},
  children:[new TextRun({font:FONT, size:21, text:
  'African commodity exporters are repeatedly hit by large swings in world commodity prices, yet the inflationary consequences of these shocks differ sharply across countries. Using a monthly panel of fifteen African commodity exporters over 2003-2026 and country-specific commodity terms-of-trade (ToT) shocks, we estimate the dynamic pass-through of external shocks to consumer-price inflation with panel local projections. Two results stand out. First, pass-through is asymmetric: favourable ToT shocks raise inflation with a hump-shaped profile that peaks near 0.10 percentage points at about ten months, whereas adverse shocks feed through more slowly; the null of symmetric transmission is rejected at horizons of six to twelve months. Second, and more importantly, the asymmetry is governed by the exchange-rate regime. Under flexible and managed regimes an adverse ToT shock is strongly inflationary (the exchange rate depreciates and imported inflation dominates), raising inflation by up to 0.3 percentage points after eighteen months. Under the CFA franc peg the same shock is mildly disinflationary, because the nominal anchor closes the depreciation channel. Favourable shocks, by contrast, are inflationary under both regimes, consistent with a fiscal-absorption channel that operates independently of the exchange rate. Regime neutrality is rejected decisively (p<0.001). The findings survive the use of an exogenous rest-of-world commodity shock, alternative inflation measures, exclusion of crisis episodes, two-way fixed effects, and the removal of thin country panels. The results imply that the optimal monetary response to commodity shocks in Africa is regime-contingent and sign-contingent, and they quantify a first-order inflation-stabilisation benefit of the CFA anchor.'})]}));
add(PR([{t:'Keywords: ',b:true},{t:'commodity terms of trade; inflation; exchange-rate regimes; CFA franc zone; asymmetric pass-through; local projections; Africa.'}],{spacingAfter:80}));
add(PR([{t:'JEL classification: ',b:true},{t:'E31, F31, F41, O55, Q02.'}],{spacingAfter:0}));
add(new Paragraph({children:[new PageBreak()]}));

// ======================= 1. INTRODUCTION ====================================
add(H1('1. Introduction'));
[
 'Few macroeconomic risks loom as large for African economies as swings in world commodity prices. For the many countries whose export earnings, fiscal revenues and import bills are concentrated in oil, metals or agricultural staples, a movement in the terms of trade is transmitted rapidly into the domestic economy through incomes, public spending, the exchange rate and, ultimately, consumer prices. The decade covered by this study alone contains the tail of the 2000s commodity super-cycle, the 2014-16 oil-price collapse, the pandemic-era demand shock of 2020, and the food and energy price surge of 2022. The Journal of African Economies has recently devoted sustained attention to how the continent absorbs and recovers from such shocks. This paper contributes to that agenda by asking a specific question: when a commodity terms-of-trade (ToT) shock hits an African economy, how much of it reaches consumer-price inflation, how does the answer depend on the sign of the shock, and how is it shaped by the exchange-rate regime?',
 'The question matters because the standard workhorse for thinking about external shocks, a linear, symmetric pass-through coefficient, may be a poor guide to African reality. There are strong theoretical reasons to expect asymmetry. Downward nominal rigidities, menu costs and the oligopolistic structure of import distribution in many African markets imply that prices rise faster than they fall (Peltzman, 2000; Meyer and von Cramon-Taubadel, 2004). At the same time, the macroeconomic meaning of a commodity shock is not the same in both directions. For a commodity exporter, a favourable ToT shock is an income windfall that tends to be spent, generating demand-pull pressure; an adverse ToT shock is an income loss that, under a flexible exchange rate, typically triggers currency depreciation and hence imported inflation, even as domestic demand contracts. Whether inflation rises or falls after a bad shock therefore depends on which of these forces dominates, and that, in turn, depends on whether the exchange rate is allowed to move.',
 'This is where Africa offers a natural laboratory that is largely absent elsewhere. The continent contains, side by side, commodity exporters operating flexible or heavily managed currencies (Nigeria, Angola, Zambia, Algeria, Mozambique and others) and the members of the CFA franc zone (in our sample Benin, Cameroon, the Central African Republic, the Republic of Congo, Gabon and Niger), whose currency has been pegged at a fixed parity to the French franc and then the euro for decades. The CFA peg is not a de facto stabilisation episode that can lapse at the first sign of trouble; it is an institutional hard peg backed by a monetary-union framework and a French Treasury guarantee. It therefore provides unusually clean variation in the single margin that theory identifies as decisive: whether the nominal exchange rate can absorb an external shock.',
 'We exploit this variation with a monthly panel of fifteen African commodity exporters spanning January 2003 to May 2026, and with country-specific commodity terms-of-trade indices constructed from each country’s export and import price structure. The shock is decomposed into its favourable (positive) and adverse (negative) components, and we trace the dynamic response of year-on-year consumer-price inflation using the panel local-projection method of Jordà (2005). Local projections are well suited to the task: they deliver the entire impulse-response path over a two-year horizon without imposing the dynamic restrictions of a vector autoregression, they accommodate sign asymmetry and regime interactions naturally, and they are robust to the kind of misspecified lag structure that plagues small-sample African data. Inference uses Driscoll-Kraay standard errors, which correct simultaneously for the cross-sectional dependence induced by common global commodity prices and for the serial correlation induced by overlapping twelve-month inflation windows.',
 'The paper makes three contributions. First, it documents robust asymmetry in commodity-shock pass-through for African economies: favourable shocks raise inflation along a hump-shaped path peaking near 0.10 percentage points at about ten months, adverse shocks act more slowly, and the null of symmetric transmission is rejected at business-cycle horizons. Second, and central to the paper, it shows that this asymmetry is governed by the exchange-rate regime. Under flexible and managed regimes an adverse ToT shock is strongly and persistently inflationary, raising inflation by roughly 0.2-0.3 percentage points over one to two years as the currency depreciates; under the CFA peg the same shock is mildly disinflationary, because the anchor closes the depreciation channel and the demand-contraction effect dominates. Favourable shocks, by contrast, are modestly inflationary under both regimes. The hypothesis that the regime is neutral for pass-through is rejected at better than the one-percent level. Third, the paper brings a credible identification strategy to a literature on African inflation that has largely relied on domestic regressors: our results are unchanged when the domestic ToT shock is replaced by an exogenous rest-of-world commodity shock that strips out any influence of the individual economy on the prices it faces.',
 'These findings speak directly to the policy debate on nominal anchors in Africa. They imply that a symmetric monetary reaction function is mis-specified for commodity exporters: the inflationary danger from a bad shock is concentrated in flexible-rate economies and operates through the exchange rate, while the inflationary danger from a good shock is a more universal demand-side phenomenon. They also quantify a first-order benefit of the CFA arrangement (the near-elimination of imported inflation following adverse terms-of-trade shocks) that must be weighed against its well-known costs in lost adjustment capacity. We return to these implications, and to their limits, in Section 7.',
 'The remainder of the paper is organised as follows. Section 2 situates the paper in the literatures on commodity shocks, asymmetric price transmission and exchange-rate regimes in Africa. Section 3 describes the data and presents five stylized facts. Section 4 sets out the empirical strategy. Section 5 reports the baseline and regime-dependent results, Section 6 the robustness analysis, and Section 7 the policy implications. Section 8 concludes.'
].forEach((t,i)=>add(P(t,{firstLine:i>0})));

// ======================= 2. LITERATURE ======================================
add(H1('2. Related literature and conceptual framework'));
add(H2('2.1 Commodity shocks, world prices and inflation in developing economies'));
[
 'A large body of work establishes that world prices are a dominant driver of macroeconomic fluctuations in small commodity-exporting economies. Kose (2002) shows that world-price shocks account for a substantial share of output volatility in developing countries; Fernández, Schmitt-Grohé and Uribe (2017) and Fernández, González and Rodríguez (2018) find that a small number of common commodity factors explain a large fraction of business-cycle comovement across emerging and developing economies. Drechsel and Tenreyro (2018) document that commodity-price fluctuations generate sizeable and persistent cycles in commodity exporters and argue that they behave like exogenous driving forces for these economies. For Africa specifically, Deaton (1999) long ago emphasised the centrality of commodity prices to growth, and recent work in this journal by Dostal (2022) documents how international commodity prices continue to shape economic performance across Sub-Saharan Africa. On the inflation side, Nguyen, Dridi, Unsal and Williams (2017) show that external factors, including global commodity and food prices, are among the leading drivers of inflation in the region. The recovery-from-shocks agenda of recent African macroeconomics has renewed interest in how these shocks propagate.',
 'The transmission of external price shocks to domestic inflation has typically been studied through the lens of exchange-rate pass-through. The classic references, Taylor (2000), Campa and Goldberg (2005), Choudhri and Hakura (2006) and Ca’ Zorzi, Hahn and Sánchez (2007), establish that pass-through is incomplete, varies with the inflation environment, and is generally larger where inflation is high and less anchored. Razafimahefa (2012) provides direct evidence for Sub-Saharan Africa, finding pass-through that is higher than in advanced economies and sensitive to the monetary regime, while Aron and Muellbauer (2007), reviewing two decades of South African monetary policy in this journal, emphasise how the exchange rate and the credibility of the nominal framework jointly shape inflation outcomes. Our commodity terms-of-trade shock is conceptually upstream of exchange-rate pass-through: it captures the external impulse itself, of which exchange-rate movements are one endogenous channel. Measuring the shock at source, rather than through the exchange rate, is what allows us to ask how the regime shapes transmission rather than assuming it.'
].forEach(t=>add(P(t)));

add(H2('2.2 Asymmetric price transmission'));
[
 'That prices "rise faster than they fall" is one of the most durable regularities in applied price analysis (Peltzman, 2000). The agricultural and energy price-transmission literatures, surveyed by Meyer and von Cramon-Taubadel (2004), document pervasive asymmetry between positive and negative cost shocks, attributed to menu costs, search frictions, inventory management and market power along the distribution chain. The econometric workhorse for capturing such asymmetry in a time-series setting is the nonlinear ARDL framework of Shin, Yu and Greenwood-Nimmo (2014), which decomposes a regressor into partial sums of its positive and negative changes. We borrow the sign-decomposition logic of that framework but implement it within panel local projections, which are better suited to a short, wide, unbalanced macro panel and which deliver the full dynamic response rather than a single long-run multiplier.',
 'For commodity exporters, asymmetry has an additional, macroeconomic source beyond micro price stickiness: the sign of a terms-of-trade shock changes its economic nature. A windfall is spent and is demand-inflationary; a loss forces external adjustment whose inflationary consequences hinge on the exchange rate. This paper is, to our knowledge, the first to bring these two strands, micro asymmetry and macro sign-dependence, together for African economies and to show that the exchange-rate regime is the hinge on which the second turns.'
].forEach(t=>add(P(t)));

add(H2('2.3 Exchange-rate regimes and shock absorption in Africa'));
[
 'The theoretical case for exchange-rate flexibility rests on its role as a shock absorber: a floating currency depreciates in response to an adverse real shock, cushioning output at the cost of some imported inflation. The countervailing "fear of floating" literature (Calvo and Reinhart, 2002) shows that many emerging and developing economies suppress this adjustment in practice, precisely because they fear its inflationary consequences. Whether a country can credibly commit to either corner is bound up with the classification of its regime; the Reinhart-Rogoff and Ilzetzki-Reinhart-Rogoff programme (Reinhart and Rogoff, 2004; Ilzetzki, Reinhart and Rogoff, 2019) has shown how far de facto arrangements can diverge from de jure announcements.',
 'The CFA franc zone occupies a special place in this debate. As a monetary union with a fixed external parity and a convertibility guarantee, it constitutes the continent’s canonical hard peg, and its members have historically experienced markedly lower nominal exchange-rate variability than their neighbours (Savvides, 1996). Devarajan and Rodrik (1991) framed the core trade-off early: the zone imports monetary credibility and low inflation at the price of forgoing nominal exchange-rate adjustment to real shocks. Gulde and Tsangarides (2008) and, more recently, Zafar (2021) provide comprehensive assessments of the zone’s performance, consistently finding markedly lower and more stable inflation than in comparable non-CFA African economies, alongside recurrent concerns about competitiveness and the capacity to absorb terms-of-trade shocks. Coudert, Couharde and Mignon (2011) examine how dollar versus euro pegging shapes real exchange-rate misalignment in the region. What this literature has not done is quantify, dynamically and with a credible external shock measure, how the peg changes the inflationary response to commodity shocks of each sign. That is the gap we fill.'
].forEach(t=>add(P(t)));

add(H2('2.4 Contribution'));
add(P('The commodity-shock, asymmetric-transmission and exchange-rate-regime literatures have largely developed in parallel. Studies of commodity shocks rarely distinguish the sign of the shock or the regime; studies of asymmetry rarely use a clean external shock; and studies of the CFA zone rarely trace dynamic inflation responses. This paper joins the three. It uses an exogenous, source-measured commodity terms-of-trade shock; it allows the response to differ by sign; it lets the exchange-rate regime moderate that response through an institutionally clean CFA-versus-non-CFA contrast; and it delivers the full two-year dynamic path with panel local projections and dependence-robust inference. The result is a sharper and more policy-relevant characterisation of how external shocks become domestic inflation in Africa than a single symmetric pass-through coefficient can provide.'));

add(H2('2.5 A two-channel framework'));
add(P('It is useful to fix ideas with a stylized account of how a commodity terms-of-trade shock reaches consumer prices in a small commodity-exporting economy. At least two channels operate, and they respond very differently to the exchange-rate regime. This framework is deliberately informal; its purpose is to generate the sign- and regime-contingent predictions that the empirical section then tests.'));
add(PR([{t:'The fiscal-absorption channel. ',b:true,i:true},{t:'In most African commodity exporters a large share of export earnings accrues to the public sector, through resource royalties, export taxes, production-sharing arrangements and the dividends of state-owned producers, and to domestic factor incomes. A favourable shock therefore raises fiscal revenue and national income, and, to the extent that it is spent, raises aggregate demand and the price of non-tradables. Let domestic inflation respond to the absorption gap, '}]));
add(PR([{t:'π',i:true},{t:'i,t',sub:true},{t:' ≈ φ · (A',i:true},{t:'i,t',sub:true},{t:' − Ā',i:true},{t:'i',sub:true},{t:'),   with   A',i:true},{t:'i,t',sub:true},{t:' = A(s',i:true},{t:'+',sup:true},{t:'i,t',sub:true},{t:', g',i:true},{t:'i,t',sub:true},{t:'),   ∂A/∂s',i:true},{t:'+',sup:true},{t:' > 0,          (5)'}],{align:AlignmentType.CENTER}));
add(P('where A is domestic absorption, Ā its sustainable level, and g government spending, which rises with commodity revenue given the well-documented procyclicality of fiscal policy in commodity exporters (Frankel, 2010; Frankel, Végh and Vuletin, 2013; Céspedes and Velasco, 2014). This channel has three properties: it is increasing in the size of a favourable shock; it is largely independent of the exchange-rate regime; indeed, under a peg a windfall cannot be partly offset by nominal appreciation, so a larger share is absorbed domestically; and it is a source of asymmetry in its own right, because the downward rigidity of public expenditure makes spending cuts after an adverse shock slower and smaller than spending increases after a favourable one.'));
add(PR([{t:'The exchange-rate channel. ',b:true,i:true},{t:'An adverse terms-of-trade shock is an external-income loss that requires adjustment of the external balance. Under a flexible regime the nominal exchange rate depreciates, and with an import pass-through coefficient θ this raises the domestic-currency price of imports and hence inflation, π'},{t:'i,t',sub:true},{t:' ≈ θ · Δe'},{t:'i,t',sub:true},{t:' with Δe'},{t:'i,t',sub:true},{t:' > 0 following an adverse shock. Under a credible hard peg Δe'},{t:'i,t',sub:true},{t:' = 0 by construction, so this channel is shut and adjustment falls instead on activity and internal prices, which is disinflationary. The exchange-rate channel is thus increasing in the size of an adverse shock and operative only under exchange-rate flexibility.'}]));
add(P('Combining the two channels yields four predictions, each of which maps to a result in Section 5. (P1) Favourable shocks are inflationary through the fiscal channel under both regimes. (P2) The favourable-shock effect is, if anything, no smaller under the peg, since the windfall is not damped by appreciation. (P3) Adverse shocks are inflationary under flexibility, because the exchange-rate channel dominates the contractionary income effect. (P4) Adverse shocks are non-inflationary or disinflationary under the peg, because the exchange-rate channel is shut and the contraction dominates. The raw asymmetry of Fact 1 and the U-shaped quintile pattern of Fact 2 are the reduced-form footprints of these two channels operating together. A direct decomposition of the fiscal channel would require harmonised high-frequency fiscal series, which are not available for most of the sample; we therefore treat the fiscal mechanism as the leading interpretation of the favourable-shock and peg results rather than as a separately estimated object, and return to it as an avenue for future work in Section 8.'));

// ======================= 3. DATA ============================================
add(new Paragraph({children:[new PageBreak()]}));
add(H1('3. Data and stylized facts'));
add(H2('3.1 Sources and sample'));
add(P('We assemble a monthly panel of fifteen African commodity exporters for which consistent series on consumer prices, exchange rates, external trade and commodity price structure are available. The underlying series are drawn from the IMF International Financial Statistics and Primary Commodity Price System, the IMF World Economic Outlook database, and the World Bank World Development Indicators, harmonised to a common monthly frequency. The effective estimation sample, observations with non-missing inflation and commodity-shock data, comprises 3,094 country-months running from January 2003 to May 2026, although most country series begin between 2005 and 2011 and the panel is unbalanced. This window is well suited to the question: it spans the late commodity super-cycle, the 2014-16 oil collapse, the 2020 pandemic shock and the 2022 food-and-energy surge, delivering ample variation in commodity shocks of both signs.'));
add(P('The sample divides naturally by exchange-rate regime. Six countries are members of the CFA franc zone (Benin, Cameroon, the Central African Republic, the Republic of Congo, Gabon and Niger), whose currency is pegged at a fixed parity to the euro; these contribute 1,228 country-months. The remaining nine (Algeria, Angola, the Democratic Republic of Congo, Liberia, Libya, Mauritania, Mozambique, Nigeria and Zambia) operate flexible or heavily managed regimes and contribute 1,866 country-months. Table 1 lists the countries, their sample coverage, and their mean inflation and commodity shock. The regime split is stark even before any modelling: mean inflation is 2.5 per cent in the CFA group and 9.3 per cent in the flexible group.'));
add(cap('Table 1. Sample composition: African commodity exporters by exchange-rate regime.'));
add(mkTable([
 ['Regime','Country','Obs','Start','End','Mean infl. (%)','SD infl.','Mean shock (pp)'],
 ['CFA peg','Benin','209','2009','2026','1.39','2.34','0.07'],
 ['CFA peg','Cameroon','182','2011','2026','2.84','1.84','0.01'],
 ['CFA peg','Central African Rep.','228','2007','2025','3.87','4.29','0.05'],
 ['CFA peg','Congo, Rep.','244','2006','2026','2.82','2.49','0.07'],
 ['CFA peg','Gabon','180','2011','2025','2.23','1.95','-0.81'],
 ['CFA peg','Niger','185','2011','2026','1.86','3.36','0.20'],
 ['Flexible','Algeria','244','2006','2026','4.68','2.54','-0.10'],
 ['Flexible','Angola','281','2003','2026','16.95','6.96','1.09'],
 ['Flexible','DR Congo','50','2013','2017','1.84','2.66','-0.31'],
 ['Flexible','Liberia','234','2006','2026','10.46','5.40','0.09'],
 ['Flexible','Libya','185','2011','2026','6.82','8.74','-0.39'],
 ['Flexible','Mauritania','185','2011','2026','3.65','2.22','-0.08'],
 ['Flexible','Mozambique','257','2005','2026','7.11','4.75','-0.01'],
 ['Flexible','Nigeria','245','2006','2026','13.22','5.63','0.05'],
 ['Flexible','Zambia','185','2011','2026','10.41','4.52','0.44'],
], [1300,1900,700,750,750,1350,900,1200], {size:16, zebra:true}));

add(H2('3.2 Variables'));
add(P('The dependent variable is year-on-year consumer-price inflation. The external impulse is a country-specific commodity terms-of-trade index, constructed in the spirit of the commodity terms-of-trade indices of Gruss and Kebhaj (2019): a geometric index of world commodity prices weighted by each country’s export and import structure, so that the index rises when the prices a country sells move favourably relative to the prices it buys. We measure the shock as the twelve-month log change of this index and decompose it into a favourable component, equal to the change when positive and zero otherwise, and an adverse component, equal to the change when negative and zero otherwise. This sign-decomposition, in the spirit of the nonlinear ARDL framework, lets the data speak to whether good and bad shocks transmit differently. A rest-of-world counterpart of the index, constructed with external weights so that it is exogenous to the individual economy, is used for identification. All shock variables are expressed in percentage points. Table 2 reports summary statistics. To limit the influence of currency redenominations and CPI rebasing, inflation is winsorised at the first and ninety-ninth percentiles; a source field for reserves in months of imports contained evident scaling errors and is excluded from the analysis.'));
add(cap('Table 2. Descriptive statistics, effective estimation sample (2003-2026).'));
add(mkTable([
 ['Variable','N','Mean','SD','p10','Median','p90'],
 ['Inflation, YoY (%)','3094','6.62','6.64','0.52','4.60','15.62'],
 ['Inflation, MoM (%)','3094','0.56','1.16','-0.65','0.45','1.92'],
 ['Commodity ToT shock, 12m (pp)','3094','0.07','7.59','-7.29','0.09','7.51'],
 ['Positive shock (pp)','3094','2.28','4.64','0.00','0.09','7.51'],
 ['Negative shock (pp)','3094','-2.21','5.10','-7.29','0.00','0.00'],
 ['RoW commodity shock, 12m (pp)','3094','0.07','8.95','-7.71','0.02','8.78'],
 ['FX depreciation, 1m (pp)','2914','0.42','3.55','-1.90','0.09','2.48'],
 ['FX volatility, 12m (pp)','2914','2.10','2.74','0.55','1.59','3.94'],
 ['Policy / money-market rate (%)','2184','5.80','3.67','1.75','4.76','10.25'],
], [3100,850,850,850,850,900,900], {size:16, zebra:true}));

add(H2('3.3 Five stylized facts'));
add(P('The raw data already point to the two themes of the paper, asymmetry and regime dependence, before any regression is run. We summarise them in five facts.'));
add(PR([{t:'Fact 1 (raw asymmetry). ',b:true},{t:'Inflation is correlated with favourable commodity shocks but not with adverse ones. The simple correlation between the positive shock component and inflation is +0.14 (p<0.001), whereas the correlation with the negative component is essentially zero (−0.01, p=0.51). Figure 1 shows this graphically: the binned relationship slopes clearly upward for positive shocks and is flat for negative shocks.'}]));
add(img(`${FIG}/fig1_asymmetry.png`, 600, 240));
add(cap('Figure 1. Binned means of year-on-year inflation against the positive (left) and negative (right) commodity-shock components. Positive shocks are associated with higher inflation; negative shocks are not.'));
add(PR([{t:'Fact 2 (non-monotone tails). ',b:true},{t:'Sorting country-months into quintiles of the commodity shock reveals a U-shape rather than a monotone relationship. Mean inflation is 7.3 per cent in the most adverse-shock quintile, falls to 4.1 per cent near zero, and rises again to 9.2 per cent in the most favourable-shock quintile. Both tails are inflationary, but through different channels: demand pressure on the upside, and, as we show below, exchange-rate depreciation on the downside. This foreshadows why a pooled linear coefficient understates the true transmission of adverse shocks.'}]));
add(PR([{t:'Fact 3 (regime and the level of inflation). ',b:true},{t:'CFA membership is associated with dramatically lower and more stable inflation. Mean inflation is 2.5 per cent (standard deviation 3.0) in the CFA group against 9.3 per cent (standard deviation 7.0) in the flexible group; the difference in means is overwhelmingly significant (t=−36.9) and the difference in variances is significant on a Levene test (p<0.001). Figure 2, panel A, shows the two inflation distributions.'}]));
add(img(`${FIG}/fig2_regime.png`, 600, 240));
add(cap('Figure 2. Panel A: inflation distributions by regime. Panel B: mean inflation across commodity-shock quintiles by regime, the CFA group is flatter and lower throughout.'));
add(PR([{t:'Fact 4 (regime and transmission). ',b:true},{t:'Panel B of Figure 2 shows that the response of inflation to shocks differs by regime, not just its level: mean inflation across shock quintiles is far flatter for CFA countries than for flexible-regime countries, hinting that the peg dampens transmission. Fact 5 (heterogeneous dynamics). Country time series (Figure 3) confirm that the association between commodity shocks and inflation is systematic but heterogeneous, pronounced in flexible-rate Nigeria, Angola and Algeria, and muted in CFA Cameroon.'}]));
add(img(`${FIG}/fig3_timeseries.png`, 600, 327));
add(cap('Figure 3. Commodity terms-of-trade shocks (bars, right axis) and year-on-year inflation (line, left axis) for four illustrative countries.'));
add(P('Table 4 reports the correlation structure of the key variables. Inflation is positively correlated with the positive shock (0.14), with FX volatility (0.20) and with the policy rate (0.43), and essentially uncorrelated with the negative shock in the pooled data (−0.01), a pooled average that, as the regressions will show, masks strong offsetting regime effects.'));
add(cap('Table 4. Correlation matrix, key variables.'));
add(mkTable([
 ['','Infl','Shk+','Shk−','ΔFX','FXvol','Rate'],
 ['Inflation','1.00','0.14','−0.01','0.07','0.20','0.43'],
 ['Positive shock','0.14','1.00','0.21','−0.02','0.11','−0.02'],
 ['Negative shock','−0.01','0.21','1.00','−0.06','0.00','0.16'],
 ['FX depreciation','0.07','−0.02','−0.06','1.00','0.20','0.04'],
 ['FX volatility','0.20','0.11','0.00','0.20','1.00','0.25'],
 ['Policy rate','0.43','−0.02','0.16','0.04','0.25','1.00'],
], [1700,900,900,900,900,900,900], {size:17, zebra:true}));

add(H2('3.4 Data quality and sample choices'));
add(P('Three features of the data deserve comment. First, inflation is missing for a non-trivial share of early country-months; we address this by relying on the unbalanced panel from 2003, by using month-on-month inflation as an alternative dependent variable in robustness, and by checking that dropping the thinnest panels (the Democratic Republic of Congo, 50 months, and Mauritania) leaves the results intact. Second, the exchange-rate regime is measured institutionally, by CFA membership, rather than by a de facto volatility classification. This is deliberate: a de facto classification built on realised US-dollar volatility misclassifies the CFA franc as a float, because the CFA/dollar rate moves with the euro/dollar rate even though the CFA/euro parity is fixed. Section 6 shows that using such a de facto measure indeed washes out the regime effect, precisely because it mislabels the continent’s hardest pegs, reinforcing the case for the institutional classification. Third, we winsorise inflation and exclude an evidently mis-scaled reserves field, as noted above.'));

// ======================= 4. EMPIRICAL STRATEGY ==============================
add(new Paragraph({children:[new PageBreak()]}));
add(H1('4. Empirical strategy'));
add(H2('4.1 Local projections and identification'));
add(P('We estimate the dynamic pass-through of commodity shocks to inflation using the panel local-projection (LP) method of Jordà (2005). For each horizon h = 0,1,…,24 months we regress inflation h months ahead on the current shock and a set of predetermined controls, and read the sequence of estimated coefficients as the impulse-response function. Relative to a panel VAR, local projections require no assumption on the joint dynamics of the system, accommodate sign asymmetry and regime interactions by simple inclusion of the relevant regressors, and are robust to the misspecified lag structures that are hard to avoid in short, heterogeneous macro panels (Ramey, 2016; Teulings and Zubanov, 2014).'));
add(P('Identification rests on the near-exogeneity of commodity terms-of-trade shocks to individual African economies. With the exception of a few large producers, the countries in our sample are price-takers in world commodity markets, so movements in the prices they face are plausibly orthogonal to their domestic inflation. We reinforce this in two ways. First, the controls include only predetermined variables, lags of inflation and of the shock, so that endogenous channels such as the contemporaneous exchange rate are not conditioned on and are left inside the estimated response. Second, in robustness we replace the country’s own commodity shock with a rest-of-world commodity shock constructed from external weights, which by construction cannot reflect the individual economy’s own conditions; the results are unchanged.'));
add(H2('4.2 Baseline asymmetric specification'));
add(P('Let πᵢ,ₜ denote year-on-year inflation in country i in month t, and let s⁺ᵢ,ₜ and s⁻ᵢ,ₜ denote the favourable and adverse components of the commodity terms-of-trade shock, defined as the twelve-month change in the index when positive (respectively negative) and zero otherwise. The baseline local projection at horizon h is:'));
add(PR([{t:'π',i:true},{t:'i,t+h',sub:true},{t:' = α',i:true},{t:'i',sub:true},{t:'ʰ + β',i:true},{t:'+',sup:true},{t:'ʰ s',i:true},{t:'+',sup:true},{t:'i,t',sub:true},{t:' + β',i:true},{t:'−',sup:true},{t:'ʰ s',i:true},{t:'−',sup:true},{t:'i,t',sub:true},{t:' + γʰ X',i:true},{t:'i,t',sub:true},{t:' + ε',i:true},{t:'i,t+h',sub:true},{t:'          (1)'}],{align:AlignmentType.CENTER}));
add(P('where αᵢʰ are country fixed effects, Xᵢ,ₜ is a vector of predetermined controls (the first, second and twelfth lags of inflation and the first lags of the two shock components), and ε is the projection residual. The coefficient β⁺ʰ traces the inflation response, h months out, to a favourable shock; β⁻ʰ traces the response to an adverse shock. Because s⁻ is a negative-valued regressor, a negative β⁻ʰ means that an adverse shock (a fall in the terms of trade) raises inflation. To aid interpretation, the figures plot the response to a one-percentage-point adverse shock, i.e. −β⁻ʰ, so that an upward line always denotes higher inflation.'));
add(P('The central test of asymmetry is the equality of the two slopes at each horizon:'));
add(PR([{t:'H',i:true},{t:'0',sub:true},{t:': β',i:true},{t:'+',sup:true},{t:'ʰ = β',i:true},{t:'−',sup:true},{t:'ʰ          (symmetric transmission)          (2)'}],{align:AlignmentType.CENTER}));
add(P('Under the null of symmetry the model collapses to a linear projection on the undecomposed shock. Rejection at a given horizon is direct evidence that good and bad shocks transmit differently at that horizon.'));
add(H2('4.3 Regime-dependent specification'));
add(P('To let the exchange-rate regime moderate transmission, we interact each shock component with an indicator CFAᵢ equal to one for CFA franc-zone members. Because CFA membership is time-invariant over the sample, its level effect is absorbed by the country fixed effects, and the interaction terms identify how the peg changes the slopes:'));
add(PR([{t:'π',i:true},{t:'i,t+h',sub:true},{t:' = α',i:true},{t:'i',sub:true},{t:'ʰ + β',i:true},{t:'+',sup:true},{t:'ʰ s',i:true},{t:'+',sup:true},{t:'i,t',sub:true},{t:' + β',i:true},{t:'−',sup:true},{t:'ʰ s',i:true},{t:'−',sup:true},{t:'i,t',sub:true},{t:' + δ',i:true},{t:'+',sup:true},{t:'ʰ (s',i:true},{t:'+',sup:true},{t:'·CFA)',i:true},{t:'i,t',sub:true},{t:' + δ',i:true},{t:'−',sup:true},{t:'ʰ (s',i:true},{t:'−',sup:true},{t:'·CFA)',i:true},{t:'i,t',sub:true},{t:' + γʰX',i:true},{t:'i,t',sub:true},{t:' + ε',i:true},{t:'i,t+h',sub:true},{t:'   (3)'}],{align:AlignmentType.CENTER}));
add(P('Here β⁺ʰ and β⁻ʰ are the pass-through slopes in the flexible-regime group and δ⁺ʰ, δ⁻ʰ measure how much the CFA peg changes them; the effective CFA slopes are β⁺ʰ+δ⁺ʰ and β⁻ʰ+δ⁻ʰ. We test whether the regime is neutral for transmission with the joint restriction:'));
add(PR([{t:'H',i:true},{t:'0',sub:true},{t:': δ',i:true},{t:'+',sup:true},{t:'ʰ = δ',i:true},{t:'−',sup:true},{t:'ʰ = 0          (regime neutrality)          (4)'}],{align:AlignmentType.CENTER}));
add(P('For the figures we also estimate a re-parameterised version of (3) in which each shock component is interacted directly with the flexible and CFA indicators (with no common term), so that the four regime-specific slopes are read off directly together with their own standard errors.'));
add(H2('4.4 Inference'));
add(P('All specifications include country fixed effects and are estimated horizon by horizon. Standard errors are of the Driscoll-Kraay type (Driscoll and Kraay, 1998) with a Bartlett kernel and a bandwidth that grows with the horizon, which corrects simultaneously for the cross-sectional dependence induced by common world commodity prices and for the serial correlation induced by the overlapping twelve-month inflation windows and by the local-projection design. A two-way fixed-effects variant that additionally absorbs common time effects, identifying pass-through purely from differential commodity exposure across countries, is reported in robustness.'));

// ======================= 5. RESULTS =========================================
add(new Paragraph({children:[new PageBreak()]}));
add(H1('5. Results'));
add(H2('5.1 Asymmetric pass-through'));
add(P('Table 5 and Figure 4 report the baseline estimates from equation (1), pooled across regimes. Favourable commodity shocks are inflationary along a hump-shaped path: the response is negligible on impact, becomes significant by six months (0.070, s.e. 0.021), peaks at about 0.10 percentage points near the ten-month horizon, remains significant at twelve months (0.085, s.e. 0.028), and fades toward zero by two years. A one-percentage-point favourable terms-of-trade shock thus raises inflation by roughly a tenth of a percentage point at its peak, which is economically meaningful given that shocks in the sample routinely exceed ten percentage points.'));
add(P('Adverse shocks behave very differently. Pooled across regimes, the adverse-shock slope is small and statistically insignificant through the first year and grows only at long horizons. This apparent muted response is, however, a pooled average that conceals sharply offsetting regime effects, as Section 5.2 shows. The test of symmetry (equation 2) rejects the null at the six-, nine- and twelve-month horizons (p = 0.004, 0.014 and 0.046 respectively; Figure 6), confirming that favourable and adverse shocks do not transmit alike over the horizons that matter most for monetary policy.'));
add(cap('Table 5. Baseline asymmetric pass-through of commodity shocks to inflation (pooled). Panel local projections with country fixed effects; Driscoll-Kraay standard errors in parentheses. *** p<0.01, ** p<0.05, * p<0.10.'));
add(mkTable([
 ['','h=0','h=3','h=6','h=12','h=18','h=24'],
 ['Positive shock (β+)','0.007','0.016','0.070***','0.085***','0.038','−0.035'],
 ['   (s.e.)','(0.014)','(0.023)','(0.021)','(0.028)','(0.031)','(0.028)'],
 ['Negative shock (β−)','−0.016','−0.035*','−0.025','−0.025','−0.097','−0.101**'],
 ['   (s.e.)','(0.010)','(0.019)','(0.020)','(0.048)','(0.075)','(0.049)'],
 ['Symmetry test p (β+=β−)','0.165','0.065','0.004','0.046','0.117','0.312'],
 ['Observations','2914','2880','2835','2745','2655','2565'],
], [2600,850,850,850,850,850,850], {size:16, zebra:true}));
add(img(`${FIG}/fig4_baseline_irf.png`, 600, 240));
add(cap('Figure 4. Baseline impulse responses of inflation to a favourable (panel A) and an adverse (panel B) one-percentage-point commodity shock, pooled across regimes. Shaded bands are 90% Driscoll-Kraay confidence intervals.'));
add(img(`${FIG}/fig6_symmetry.png`, 440, 257));
add(cap('Figure 6. p-value of the test of symmetric pass-through (β+ = β−) by horizon. Symmetry is rejected at conventional levels over the six-to-twelve-month range.'));

add(H2('5.2 The exchange-rate regime is the hinge'));
add(P('Table 6 and Figure 5 report the regime-dependent estimates. The result is the centrepiece of the paper. For favourable shocks, the two regimes look broadly similar: the response is positive and hump-shaped in both, somewhat larger and more precisely estimated in the CFA group (0.112, s.e. 0.032, at twelve months) than in the flexible group (0.067, s.e. 0.053), but the difference between them is not statistically significant at any horizon: a windfall is spent, and prices rise, whether or not the currency is pegged.'));
add(P('For adverse shocks the two regimes diverge dramatically. In flexible-regime economies an adverse terms-of-trade shock is strongly and persistently inflationary: the effective response builds from 0.12 percentage points at six months to about 0.21 at twelve months and 0.29 at eighteen months (all significant), as the currency depreciates and imported inflation takes hold. In the CFA zone the same shock is mildly disinflationary: the effective slope has the opposite sign, so that a fall in the terms of trade lowers inflation by around 0.14 percentage points at twelve months. The peg closes the depreciation channel, leaving the demand-contraction effect of the income loss to dominate. The interaction terms are large and highly significant, the adverse-shock interaction reaches 0.35 at twelve months (s.e. 0.034), and the joint test of regime neutrality (equation 4) is rejected at better than the one-percent level from the six-month horizon onward.'));
add(cap('Table 6. Regime-specific pass-through of commodity shocks to inflation. Regime-specific slopes from the re-parameterised local projection; Driscoll-Kraay standard errors in parentheses. Final row: p-value of the joint test that the CFA interaction terms are zero. *** p<0.01, ** p<0.05, * p<0.10.'));
add(mkTable([
 ['','h=0','h=3','h=6','h=12','h=18','h=24'],
 ['Positive × Flexible','0.011','0.018','0.056','0.067','0.015','−0.054'],
 ['   (s.e.)','(0.015)','(0.035)','(0.048)','(0.053)','(0.058)','(0.042)'],
 ['Positive × CFA','0.003','0.018','0.088**','0.112***','0.069***','−0.011'],
 ['   (s.e.)','(0.016)','(0.031)','(0.043)','(0.032)','(0.023)','(0.031)'],
 ['Negative × Flexible','−0.025**','−0.096***','−0.119***','−0.207**','−0.289**','−0.217**'],
 ['   (s.e.)','(0.011)','(0.025)','(0.030)','(0.088)','(0.139)','(0.104)'],
 ['Negative × CFA','−0.008','0.022','0.063**','0.144***','0.082**','0.007'],
 ['   (s.e.)','(0.011)','(0.021)','(0.026)','(0.034)','(0.039)','(0.026)'],
 ['Regime-neutrality p','0.128','0.000','0.000','0.000','0.000','0.020'],
], [2400,900,900,900,900,900,900], {size:15, zebra:true}));
add(img(`${FIG}/fig5_regime_irf.png`, 620, 260));
add(cap('Figure 5. Impulse responses of inflation by exchange-rate regime, to a favourable (panel A) and an adverse (panel B) one-percentage-point commodity shock. Solid red: flexible/managed regimes; dashed blue: CFA peg. An upward line denotes higher inflation. Shaded bands are 90% Driscoll-Kraay confidence intervals.'));

add(H2('5.3 Interpretation'));
add(P('The regime-dependent estimates confirm the four predictions of the two-channel framework of Section 2.5 point by point. Favourable shocks are inflationary under both regimes (P1), consistent with a fiscal-absorption channel that does not depend on the exchange rate; the effect is if anything slightly larger and more precisely estimated under the CFA peg (P2), exactly as expected when a windfall cannot be damped by nominal appreciation and is therefore more fully absorbed at home. Adverse shocks are strongly inflationary under flexible regimes (P3), the signature of the exchange-rate channel, and disinflationary under the peg (P4), where that channel is shut and the contractionary income effect dominates.'));
add(P('The framework also rationalises the stylized facts. The pooled adverse-shock coefficient of Section 5.1 was small because it averages a strongly inflationary flexible-regime response against a mildly disinflationary CFA response; splitting by regime restores the signal. The U-shaped quintile pattern of Fact 2, both tails inflationary, is the reduced-form footprint of the flexible-regime economies, in which favourable shocks raise inflation through the fiscal channel and adverse shocks raise it through the exchange-rate channel. And the flat, low CFA inflation of Fact 3 is the visible counterpart of a regime in which the depreciation channel is closed: favourable windfalls still leak modestly into prices through absorption, but adverse shocks, far from igniting inflation, are associated with disinflation. In short, exchange-rate flexibility converts adverse terms-of-trade shocks into inflation, whereas the hard peg absorbs them, while the fiscal channel keeps favourable shocks inflationary under either arrangement.'));

// ======================= 6. ROBUSTNESS ======================================
add(H1('6. Robustness'));
add(P('Table 7 summarises the robustness of the two key coefficients, the flexible-regime adverse-shock slope and the CFA adverse-shock interaction, at the twelve-month horizon, across six alternative specifications. The pattern is stable throughout. Most important, replacing the country’s own commodity shock with the exogenous rest-of-world commodity shock leaves the interaction large and significant (0.278, p=0.002): because the rest-of-world shock cannot reflect the individual economy’s own conditions, this rules out reverse causality from domestic inflation to measured commodity prices. The interaction is likewise robust to using annualised month-on-month inflation (0.424, p=0.003), to excluding crisis (bust) months (0.343, p<0.001), to adding common time fixed effects so that identification comes only from differential commodity exposure (0.341, p<0.001), and to dropping the two thinnest country panels (0.355, p<0.001). The flexible-regime adverse-shock slope remains negative, i.e. inflationary, across all of these.'));
add(P('The final row makes the methodological point of Section 3.4 concrete. When the regime is measured by the dataset’s de facto, US-dollar-volatility-based peg dummy instead of by CFA membership, the interaction collapses to insignificance (−0.082, p=0.28) and the flexible-regime adverse-shock effect vanishes. This is exactly what one expects if that de facto measure mislabels the CFA franc, the continent’s hardest peg, as a float: the true regime contrast is dissolved. The contrast between this row and the others is itself evidence that the mechanism operates through the institutional peg.'));
add(cap('Table 7. Robustness of the key coefficients at the twelve-month horizon. Reported: flexible-regime adverse-shock slope (β−) and CFA adverse-shock interaction (δ−), with p-values. All specifications include country fixed effects and Driscoll-Kraay standard errors.'));
add(mkTable([
 ['Specification','β− (flexible)','p','δ− (CFA interaction)','p'],
 ['Baseline (own ToT shock)','−0.207','0.018','0.351','0.000'],
 ['Rest-of-world exogenous shock','−0.136','0.142','0.278','0.002'],
 ['Month-on-month inflation (annualised)','−0.351','0.041','0.424','0.003'],
 ['Exclude bust months','−0.213','0.011','0.343','0.000'],
 ['Add time fixed effects','−0.246','0.002','0.341','0.000'],
 ['Drop thin panels (DRC, Mauritania)','−0.206','0.027','0.355','0.000'],
 ['De-facto peg dummy (state_peg)','−0.015','0.751','−0.082','0.280'],
], [3400,1500,900,1900,900], {size:16, zebra:true}));

// ======================= 7. POLICY ==========================================
add(H1('7. Policy implications'));
add(P('The results carry three implications for the conduct of monetary and exchange-rate policy in African commodity exporters. First, the optimal monetary response to a commodity shock is sign-contingent, not symmetric. A symmetric reaction function, tightening after good news by as much as it eases after bad news, is mis-specified for these economies, because favourable and adverse shocks reach inflation through different channels and with different force. In flexible-regime economies in particular, the inflationary danger is concentrated in adverse shocks and operates through the exchange rate; central banks in these economies should treat a negative terms-of-trade shock as an inflation risk to be leaned against, even though the same shock is contractionary for output, and should be correspondingly more relaxed about the inflation consequences of a positive shock than a mechanical rule would suggest.'));
add(P('Second, the results quantify a first-order benefit of a credible nominal anchor. Membership of the CFA franc zone is associated not only with lower average inflation but, specifically, with the near-elimination of the imported-inflation response to adverse terms-of-trade shocks. For economies whose principal source of inflation volatility is external and passes through the exchange rate, a hard peg or an equivalently credible anchor delivers a tangible stabilisation dividend. This does not settle the regime-choice question, the same rigidity that shuts the inflation channel also forecloses the real-adjustment channel, so that a country pegged through a persistent adverse shock must adjust through activity and internal prices rather than the exchange rate, a cost our inflation-focused analysis does not measure. But it does establish that the inflation side of the ledger favours the anchor more strongly than a symmetric view would imply. The anchor is not, however, a complete solution: favourable shocks remain inflationary under the peg through the fiscal-absorption channel, and are if anything transmitted somewhat more fully because the windfall cannot be offset by appreciation. Pegged commodity exporters therefore still require a fiscal framework, stabilisation funds, spending rules, and the sterilisation of windfalls, to contain demand-driven inflation during booms, since the exchange-rate anchor addresses the external channel but not the domestic-absorption one.'));
add(P('Third, for the flexible and managed-float economies that make up the majority of the continent’s commodity exporters, the priority is to build the monetary credibility that would let the exchange rate absorb shocks without igniting an inflation spiral. Where depreciation passes rapidly into prices, the shock-absorber benefit of flexibility is undercut by its inflation cost, the "fear of floating" trap. Deepening foreign-exchange markets, strengthening the credibility and communication of inflation objectives, and using targeted and rules-based foreign-exchange intervention to smooth disorderly adjustment are the natural levers. The general lesson is that the value of exchange-rate flexibility as a shock absorber is conditional on the domestic nominal framework, and that the two must be designed together.'));

// ======================= 8. CONCLUSION ======================================
add(H1('8. Conclusion'));
add(P('This paper has asked how commodity terms-of-trade shocks become domestic inflation in African economies, and how the answer depends on the sign of the shock and the exchange-rate regime. Using a monthly panel of fifteen African commodity exporters over 2003-2026 and panel local projections, we find that pass-through is asymmetric and, above all, regime-dependent. Favourable shocks are modestly inflationary under both pegged and flexible regimes. Adverse shocks, by contrast, are strongly and persistently inflationary under flexible regimes, working through currency depreciation, yet mildly disinflationary under the CFA franc peg, which closes that channel. The regime is neutral neither for the level of inflation nor for its response to shocks, and the transmission difference is decisively significant and robust, including to an exogenous rest-of-world commodity shock that guards against reverse causality.'));
add(P('The central message is that a single symmetric pass-through coefficient is an inadequate summary of how external shocks reach African inflation, and that the exchange-rate regime is the hinge on which transmission turns. The findings support sign-contingent monetary reaction functions, they quantify an inflation-stabilisation benefit of a credible nominal anchor, and they underscore that the shock-absorbing value of exchange-rate flexibility depends on the credibility of the domestic monetary framework. Several extensions suggest themselves: distinguishing food from energy and metals shocks, whose distributional and pass-through profiles differ; separating the fiscal and exchange-rate channels of transmission directly; and modelling the endogenous choice of regime. We leave these to future work. The results here establish the first-order fact, that in African commodity exporters, the exchange-rate regime decides whether a bad terms-of-trade shock becomes inflation or not.'));

// ======================= REFERENCES =========================================
add(new Paragraph({children:[new PageBreak()]}));
add(H1('References'));
const refs = [
 'Aron, J. and Muellbauer, J. (2007). Review of monetary policy in South Africa since 1994. Journal of African Economies, 16(5), 705-744.',
 'Ca’ Zorzi, M., Hahn, E. and Sánchez, M. (2007). Exchange rate pass-through in emerging markets. European Central Bank Working Paper No. 739.',
 'Calvo, G. A. and Reinhart, C. M. (2002). Fear of floating. Quarterly Journal of Economics, 117(2), 379-408.',
 'Campa, J. M. and Goldberg, L. S. (2005). Exchange rate pass-through into import prices. Review of Economics and Statistics, 87(4), 679-690.',
 'Céspedes, L. F. and Velasco, A. (2014). Was this time different? Fiscal policy in commodity republics. Journal of Development Economics, 106, 92-106.',
 'Choudhri, E. U. and Hakura, D. S. (2006). Exchange rate pass-through to domestic prices: does the inflationary environment matter? Journal of International Money and Finance, 25(4), 614-639.',
 'Coudert, V., Couharde, C. and Mignon, V. (2011). Does euro or dollar pegging impact the real exchange rate? The case of oil and commodity currencies. The World Economy, 34(9), 1557-1592.',
 'Deaton, A. (1999). Commodity prices and growth in Africa. Journal of Economic Perspectives, 13(3), 23-40.',
 'Devarajan, S. and Rodrik, D. (1991). Do the benefits of fixed exchange rates outweigh their costs? The Franc Zone in Africa. NBER Working Paper No. 3727.',
 'Dostal, J. M. (2022). Natural resources, international commodity prices and economic performance in Sub-Saharan Africa (1990-2019). Journal of African Economies, 31(1), 53-74.',
 'Drechsel, T. and Tenreyro, S. (2018). Commodity booms and busts in emerging economies. Journal of International Economics, 112, 200-218.',
 'Driscoll, J. C. and Kraay, A. C. (1998). Consistent covariance matrix estimation with spatially dependent panel data. Review of Economics and Statistics, 80(4), 549-560.',
 'Fernández, A., González, A. and Rodríguez, D. (2018). Sharing a ride on the commodities roller coaster: common factors in business cycles of emerging economies. Journal of International Economics, 111, 99-121.',
 'Fernández, A., Schmitt-Grohé, S. and Uribe, M. (2017). World shocks, world prices, and business cycles: an empirical investigation. Journal of International Economics, 108, S2-S14.',
 'Frankel, J. A. (2010). Monetary policy in emerging markets: a survey. NBER Working Paper No. 16125.',
 'Frankel, J. A., Végh, C. A. and Vuletin, G. (2013). On graduation from fiscal procyclicality. Journal of Development Economics, 100(1), 32-47.',
 'Gruss, B. and Kebhaj, S. (2019). Commodity terms of trade: a new database. IMF Working Paper No. 19/21.',
 'Gulde, A.-M. and Tsangarides, C. (eds.) (2008). The CFA Franc Zone: Common Currency, Uncommon Challenges. Washington, DC: International Monetary Fund.',
 'Ilzetzki, E., Reinhart, C. M. and Rogoff, K. S. (2019). Exchange arrangements entering the twenty-first century: which anchor will hold? Quarterly Journal of Economics, 134(2), 599-646.',
 'Jordà, Ò. (2005). Estimation and inference of impulse responses by local projections. American Economic Review, 95(1), 161-182.',
 'Kose, M. A. (2002). Explaining business cycles in small open economies: how much do world prices matter? Journal of International Economics, 56(2), 299-327.',
 'Meyer, J. and von Cramon-Taubadel, S. (2004). Asymmetric price transmission: a survey. Journal of Agricultural Economics, 55(3), 581-611.',
 'Nguyen, A. D. M., Dridi, J., Unsal, D. F. and Williams, O. H. (2017). On the drivers of inflation in Sub-Saharan Africa. International Economics, 151, 71-84.',
 'Peltzman, S. (2000). Prices rise faster than they fall. Journal of Political Economy, 108(3), 466-502.',
 'Ramey, V. A. (2016). Macroeconomic shocks and their propagation. In J. B. Taylor and H. Uhlig (eds.), Handbook of Macroeconomics, vol. 2A. Amsterdam: Elsevier, 71-162.',
 'Razafimahefa, I. F. (2012). Exchange rate pass-through in Sub-Saharan African economies and its determinants. IMF Working Paper No. 12/141.',
 'Reinhart, C. M. and Rogoff, K. S. (2004). The modern history of exchange rate arrangements: a reinterpretation. Quarterly Journal of Economics, 119(1), 1-48.',
 'Savvides, A. (1996). CFA franc zone membership and exchange rate variability. Journal of African Economies, 5(1), 52-68.',
 'Shin, Y., Yu, B. and Greenwood-Nimmo, M. (2014). Modelling asymmetric cointegration and dynamic multipliers in a nonlinear ARDL framework. In R. C. Sickles and W. C. Horrace (eds.), Festschrift in Honor of Peter Schmidt. New York: Springer, 281-314.',
 'Taylor, J. B. (2000). Low inflation, pass-through, and the pricing power of firms. European Economic Review, 44(7), 1389-1408.',
 'Teulings, C. N. and Zubanov, N. (2014). Is economic recovery a myth? Robust estimation of impulse responses. Journal of Applied Econometrics, 29(3), 497-514.',
 'Zafar, A. (2021). The CFA Franc Zone: Economic Development and the Post-Covid Recovery. Cham: Palgrave Macmillan.'
];
refs.forEach(r=>add(new Paragraph({alignment:AlignmentType.JUSTIFIED, spacing:{after:100,line:264},
  indent:{left:360,hanging:360},
  children:[new TextRun({text:r, font:FONT, size:20})]})));

// footer with page numbers
const doc = new Document({
  creator:'JAE manuscript', title:'Asymmetric Pass-Through of Commodity Shocks to Inflation in Africa',
  sections:[{
    properties:{page:{size:{width:12240,height:15840}, margin:{top:1440,bottom:1440,left:1440,right:1440}}},
    footers:{default:new Footer({children:[new Paragraph({alignment:AlignmentType.CENTER,
      children:[new TextRun({children:[PageNumber.CURRENT], font:FONT, size:18})]})]})},
    children: body
  }]
});
Packer.toBuffer(doc).then(b=>{fs.writeFileSync(OUT,b);console.log('WROTE',OUT,b.length,'bytes');});
