"""Remove em-dashes from the manuscript sources, replacing with natural
punctuation (parentheses / colon / semicolon / comma). En-dashes in ranges
are left untouched."""
import re

# (substring_with_emdash, replacement) applied BEFORE the global comma pass.
# Written twice: EM for docx/cover (U+2014), TEX for latex (---).
SPECIAL = [
 ("inflationary{D}the exchange rate depreciates and imported inflation dominates{D}raising",
  "inflationary (the exchange rate depreciates and imported inflation dominates), raising"),
 ("CFA arrangement{D}the near-elimination of imported inflation following adverse terms-of-trade shocks{D}that must be weighed",
  "CFA arrangement (the near-elimination of imported inflation following adverse terms-of-trade shocks) that must be weighed"),
 ("exchange-rate regime{D}indeed, under a peg", "exchange-rate regime; indeed, under a peg"),
 ("significant at any horizon{D}a windfall is spent", "significant at any horizon: a windfall is spent"),
 ("different channels{D}demand pressure on the upside", "different channels: demand pressure on the upside"),
 ("at its peak{D}economically meaningful", "at its peak, which is economically meaningful"),
 ("common time effects{D}identifying pass-through purely from", "common time effects, identifying pass-through purely from"),
 ("these two strands{D}micro asymmetry and macro sign-dependence{D}together",
  "these two strands, micro asymmetry and macro sign-dependence, together"),
 ("pattern of Fact 2{D}both tails inflationary{D}is the reduced",
  "pattern of Fact 2, both tails inflationary, is the reduced"),
 ("slope remains negative{D}i.e. inflationary{D}across all",
  "slope remains negative, i.e. inflationary, across all"),
 ("mislabels the CFA franc{D}the continent’s hardest peg{D}as a float",
  "mislabels the CFA franc, the continent’s hardest peg, as a float"),
 # cover letter
 ("inflationary{D}the currency depreciates and imported inflation dominates",
  "inflationary, as the currency depreciates and imported inflation dominates,"),
 ("developed in parallel{D}commodity shocks", "developed in parallel: commodity shocks"),
 ("regimes in Africa{D}within a credible identification", "regimes in Africa, within a credible identification"),
 ("replication package{D}data, code and output{D}is available",
  "replication package (data, code and output) is available"),
]

def process(path, dash):
    s = open(path,encoding='utf-8').read()
    before = s.count(dash) if dash!='---' else len(re.findall('---', s))
    for pat, rep in SPECIAL:
        s = s.replace(pat.replace('{D}', dash), rep)
    # global: any remaining em-dash -> comma
    if dash == '---':
        s = s.replace('---', ', ')
    else:
        s = s.replace(dash, ', ')
    after = s.count('—') + len(re.findall('---', s))
    open(path,'w',encoding='utf-8').write(s)
    print(f"{path}: removed em-dashes, {before} -> remaining {after}")

process('/root/jae_paper/code/make_docx.js', '—')
process('/root/jae_paper/code/cover_letter.js', '—')
process('/root/jae_paper/latex/JAE_manuscript.tex', '---')
