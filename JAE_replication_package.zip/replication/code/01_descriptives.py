"""
01_descriptives.py  -- descriptive tables, correlation matrix, stylized facts.
Writes machine-readable JSON of every number used in the paper (results_desc.json)
and three publication figures.
"""
import pandas as pd, numpy as np, json
from scipy import stats
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

PANEL="/root/jae_paper/output/africa_panel.csv"
FIG="/root/jae_paper/figures"; TAB="/root/jae_paper/tables"; OUT="/root/jae_paper/output"
plt.rcParams.update({"font.size":10,"axes.spines.top":False,"axes.spines.right":False,
                     "figure.dpi":150,"savefig.bbox":"tight"})
CFA_C="#1f77b4"; NON_C="#d62728"; POS_C="#2ca02c"; NEG_C="#d62728"

d=pd.read_csv(PANEL,parse_dates=['date'])
eff=d[d.insample==1].copy()
R={}

# ---------------------------------------------------------------- Table: sample
comp=(eff.groupby(['cfa','name'])
        .agg(N=('infl_yoy','size'),
             start=('date',lambda s:s.min().year),
             end=('date',lambda s:s.max().year),
             mean_infl=('infl_yoy','mean'),
             sd_infl=('infl_yoy','std'),
             mean_shock=('d_shock_12m_pp','mean'))
        .round(2).reset_index())
comp['regime']=np.where(comp.cfa==1,'CFA peg','Flexible/managed')
comp=comp[['regime','name','N','start','end','mean_infl','sd_infl','mean_shock']]
comp.to_csv(f"{TAB}/tab1_sample.csv",index=False)
R['sample']={'n_obs':int(len(eff)),'n_countries':int(eff.country.nunique()),
             'n_cfa_obs':int((eff.cfa==1).sum()),'n_noncfa_obs':int((eff.cfa==0).sum()),
             'n_cfa_countries':int(eff[eff.cfa==1].country.nunique()),
             'n_noncfa_countries':int(eff[eff.cfa==0].country.nunique()),
             'date_min':str(eff.date.min().date()),'date_max':str(eff.date.max().date())}

# ---------------------------------------------------------- Table: descriptives
vars_=['infl_yoy','infl_mom','d_shock_12m_pp','shock_pos_pp','shock_neg_pp',
       'd_shock_rw_12m_pp','dlfx_1m','fxvol','polrate']
labels={'infl_yoy':'Inflation, YoY (%)','infl_mom':'Inflation, MoM (%)',
        'd_shock_12m_pp':'Commodity ToT shock, 12m (pp)','shock_pos_pp':'Positive shock (pp)',
        'shock_neg_pp':'Negative shock (pp)','d_shock_rw_12m_pp':'RoW commodity shock, 12m (pp)',
        'dlfx_1m':'FX depreciation, 1m (pp)','fxvol':'FX volatility, 12m (pp)',
        'resmonths':'Reserves (months imports)','polrate':'Policy/mkt rate (%)'}
def dstat(g):
    return pd.Series({'N':g.notna().sum(),'mean':g.mean(),'sd':g.std(),
                      'p10':g.quantile(.1),'median':g.median(),'p90':g.quantile(.9)})
desc=pd.DataFrame({labels[v]:dstat(eff[v]) for v in vars_}).T.round(2)
desc.to_csv(f"{TAB}/tab2_descriptives.csv")

# --------------------------------------------------- STYLIZED FACT 1: asymmetry
sub=eff.dropna(subset=['infl_yoy','shock_pos_pp','shock_neg_pp'])
cp=stats.pearsonr(sub.shock_pos_pp,sub.infl_yoy)
cn=stats.pearsonr(sub.shock_neg_pp,sub.infl_yoy)
R['fact1']={'corr_pos':round(cp[0],3),'p_pos':round(cp[1],4),
            'corr_neg':round(cn[0],3),'p_neg':round(cn[1],4)}
# quintiles of the 12m shock -> mean inflation (monotonicity)
sub2=eff.dropna(subset=['infl_yoy','d_shock_12m_pp']).copy()
sub2['q']=pd.qcut(sub2.d_shock_12m_pp,5,labels=[1,2,3,4,5])
qtab=sub2.groupby('q',observed=True).agg(mean_shock=('d_shock_12m_pp','mean'),
        mean_infl=('infl_yoy','mean'),n=('infl_yoy','size')).round(2)
R['fact2_quintiles']=qtab.reset_index().astype(str).to_dict('records')

# ------------------------------------------ STYLIZED FACT 3: regime differences
cfa_i=eff[eff.cfa==1].infl_yoy.dropna(); non_i=eff[eff.cfa==0].infl_yoy.dropna()
tt=stats.ttest_ind(cfa_i,non_i,equal_var=False)
lt=stats.levene(cfa_i,non_i)
R['fact3']={'cfa_mean':round(cfa_i.mean(),2),'cfa_sd':round(cfa_i.std(),2),
            'non_mean':round(non_i.mean(),2),'non_sd':round(non_i.std(),2),
            't_stat':round(tt.statistic,2),'t_p':round(tt.pvalue,4),
            'levene_p':round(lt.pvalue,4)}

# ---------------------------------------- correlation matrix (key vars) : Tab 4
cm=eff[['infl_yoy','shock_pos_pp','shock_neg_pp','dlfx_1m','fxvol','resmonths','polrate']].corr().round(2)
cm.columns=['Infl','Shk+','Shk-','dFX','FXvol','Res','Rate']; cm.index=cm.columns
cm.to_csv(f"{TAB}/tab4_corr.csv")

# =========================================================== FIGURE 1: asymmetry
fig,ax=plt.subplots(1,2,figsize=(10,4))
# binscatter helper
def binsc(x,y,nb=20):
    dd=pd.DataFrame({'x':x,'y':y}).dropna()
    dd['b']=pd.qcut(dd.x,nb,duplicates='drop')
    g=dd.groupby('b',observed=True).agg(x=('x','mean'),y=('y','mean'))
    return g.x,g.y
for a,(var,lab,col) in zip(ax,[('shock_pos_pp','Positive commodity shock (pp)',POS_C),
                               ('shock_neg_pp','Negative commodity shock (pp)',NEG_C)]):
    xs,ys=binsc(sub[var],sub.infl_yoy)
    a.scatter(xs,ys,s=28,color=col,alpha=.85,zorder=3)
    z=np.polyfit(sub[var],sub.infl_yoy,1); xr=np.linspace(sub[var].min(),sub[var].max(),50)
    a.plot(xr,np.polyval(z,xr),color='k',lw=1.5)
    a.set_xlabel(lab); a.set_ylabel('Inflation YoY (%)')
    a.set_title(f"slope={z[0]:.3f},  r={stats.pearsonr(sub[var],sub.infl_yoy)[0]:.3f}")
fig.suptitle("Figure 1. Asymmetric association of commodity shocks with inflation\n"
             "(binned means, 15 African commodity exporters)",fontsize=11)
fig.tight_layout(); fig.savefig(f"{FIG}/fig1_asymmetry.png"); plt.close(fig)

# =========================================================== FIGURE 2: regimes
fig,ax=plt.subplots(1,2,figsize=(10,4))
# panel A: distribution
ax[0].hist(non_i,bins=40,alpha=.55,color=NON_C,density=True,label=f"Flexible (μ={non_i.mean():.1f}, σ={non_i.std():.1f})")
ax[0].hist(cfa_i,bins=40,alpha=.55,color=CFA_C,density=True,label=f"CFA peg (μ={cfa_i.mean():.1f}, σ={cfa_i.std():.1f})")
ax[0].set_xlim(-15,40); ax[0].set_xlabel('Inflation YoY (%)'); ax[0].set_ylabel('Density')
ax[0].legend(fontsize=8); ax[0].set_title('A. Inflation distribution by regime')
# panel B: quintile response by regime
subr=eff.dropna(subset=['infl_yoy','d_shock_12m_pp']).copy()
subr['q']=pd.qcut(subr.d_shock_12m_pp,5,labels=[1,2,3,4,5])
gg=subr.groupby(['cfa','q'],observed=True).infl_yoy.mean().unstack(0)
q=np.arange(1,6); w=.38
ax[1].bar(q-w/2,gg[0],w,color=NON_C,label='Flexible')
ax[1].bar(q+w/2,gg[1],w,color=CFA_C,label='CFA peg')
ax[1].set_xticks(q); ax[1].set_xlabel('Commodity shock quintile (1=most negative)')
ax[1].set_ylabel('Mean inflation YoY (%)'); ax[1].legend(fontsize=8)
ax[1].set_title('B. Inflation across shock quintiles, by regime')
fig.suptitle("Figure 2. Exchange-rate regime and inflation outcomes",fontsize=11)
fig.tight_layout(); fig.savefig(f"{FIG}/fig2_regime.png"); plt.close(fig)

# =========================================================== FIGURE 3: time series
fig,ax=plt.subplots(2,2,figsize=(11,6),sharex=True)
show=[('NGA','Nigeria (flexible)'),('DZA','Algeria (flexible)'),
      ('CMR','Cameroon (CFA peg)'),('AGO','Angola (flexible)')]
for a,(c,t) in zip(ax.ravel(),show):
    s=d[d.country==c].sort_values('date')
    a2=a.twinx()
    a.plot(s.date,s.infl_yoy,color='k',lw=1.2,label='Inflation')
    a2.bar(s.date,s.d_shock_12m_pp,width=25,color=np.where(s.d_shock_12m_pp>=0,POS_C,NEG_C),alpha=.5)
    a.set_title(t,fontsize=10); a.set_ylabel('Infl %',fontsize=8)
    a2.set_ylabel('Shock pp',fontsize=8,color='gray')
    a.set_zorder(a2.get_zorder()+1); a.patch.set_visible(False)
fig.suptitle("Figure 3. Commodity terms-of-trade shocks (bars) and inflation (line)",fontsize=11)
fig.tight_layout(); fig.savefig(f"{FIG}/fig3_timeseries.png"); plt.close(fig)

json.dump(R,open(f"{OUT}/results_desc.json","w"),indent=2)
print("=== DESCRIPTIVE RESULTS ===")
print(json.dumps(R,indent=2))
print("\nSaved tables tab1-4, figures fig1-3.")
