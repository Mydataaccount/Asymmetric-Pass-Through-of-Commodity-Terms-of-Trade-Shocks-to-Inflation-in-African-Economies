# Replication package
### "Asymmetric Pass-Through of Commodity Terms-of-Trade Shocks to Inflation in African Economies: The Role of the CFA Franc Peg"
*Prepared for the Journal of African Economies.*

## What this does
Estimates the dynamic pass-through of commodity terms-of-trade (ToT) shocks to
CPI inflation in 15 African commodity exporters (monthly, 2003–2026), allowing
the response to differ by the sign of the shock and by exchange-rate regime
(CFA franc peg vs. flexible/managed), using **panel local projections**
(Jordà 2005) with **Driscoll–Kraay** standard errors.

## Data
Input: `lp_panel.csv` — the supplied global commodity-exporter panel. Only the
15 African countries are used. Key fields:
- `infl_yoy`, `infl_mom` — CPI inflation.
- `shock_ix` / `d_shock_12m` — country commodity ToT index and its 12m log change.
- `shock_pos = max(d_shock_12m,0)`, `shock_neg = min(d_shock_12m,0)` — sign decomposition.
- `shock_rw_*` — rest-of-world (exogenous) counterparts, used for identification.
- `state_peg` — dataset's de-facto peg dummy (used only as a robustness contrast;
  it misclassifies the CFA zone, see paper §3.4 and §6).

Regime is defined **institutionally**: CFA = {BEN, CMR, CAF, COG, GAB, NER}.

## Pipeline (run in order, from this folder)
```bash
pip install pandas numpy statsmodels linearmodels matplotlib scipy
python 00_dataprep.py      # -> output/africa_panel.csv  (subset, CFA dummy, winsorise)
python 01_descriptives.py  # -> tables tab1-4, figures fig1-3, results_desc.json
python 02_estimate.py      # -> lp_baseline.csv, lp_regime.csv, wald_*, results_lp.json
python 04_regime_irf.py    # -> lp_regime_specific.csv (regime-specific slopes+SEs)
python 03_robustness.py    # -> robustness.csv (6 alternative specifications)
python 05_figures.py       # -> figures fig4-6 (IRFs, symmetry test)
node   make_docx.js        # -> output/JAE_manuscript.docx
```
`lp_engine.py` holds the reusable LP estimator and Wald tests.

## Key results (12-month horizon)
- Favourable shock: +0.085pp (p<0.01), hump-shaped, peaks ~0.10 at h≈10.
- Symmetry (β+=β−) rejected at h=6–12.
- Adverse shock × Flexible: strongly inflationary (−0.207 on shock_neg ⇒ inflation rises).
- Adverse shock × CFA interaction: +0.351 (p<0.001) ⇒ peg reverses the sign (mildly disinflationary).
- Regime neutrality rejected at p<0.001. Robust to exogenous RoW shock, infl_mom,
  excluding busts, time FE, and dropping thin panels.

## Notes / caveats
- `reserves_months` in the source has scaling errors and is excluded.
- Inflation winsorised at 1/99 pct to remove redenomination/rebasing breaks.
- References in the manuscript are real published works; verify page numbers
  against the JAE house style before submission.
